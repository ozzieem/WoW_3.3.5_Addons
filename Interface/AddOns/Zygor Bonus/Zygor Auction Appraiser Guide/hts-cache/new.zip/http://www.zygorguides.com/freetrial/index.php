<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--
##  Zygor Guides | version 1.0 | "PEACH"
##  [ www.zygorguides.com ] [ www.tikitula.com ]
##
##  All contents within are Copyright © 2008, Zygor Guides LLC & The Tiki Tula.
##  All Rights Reserved ® 
-->
<head>
<title>Zygor Guides</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="The #1 best-selling in-game World of Warcraft leveling guides." />
<meta name="keywords" content="world of warcraft guide, world of warcraft leveling, wow leveling guide, alliance leveling guide, horde leveling guide, 1-80 leveling guide, in game leveling guides" />
<meta name="language" content="en-us, english" />
<meta name="classification" content="Blog" />
<meta name="author" content="Andrew Sturgeon" />
<meta name="copyright" content="Zygor Guides LLC" />
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="alternate" type="application/rss+xml" title="The Zygor Guides News Feed" href="http://feeds.feedburner.com/zygorguides" />
<style type='text/css' media='screen'>
<!--
@import url(../css/peach.css);
.arthas form{
text-align: center;
margin-top: 80px;
}

.arthas {
float: left;
margin-left: 100px;
margin-bottom: 10px;
width: 320px;
height: 280px;
background: url(http://www.zygorguides.com/img/lichking.png) top center no-repeat;}

.arthas form label {
display: block;
font-size: 1.4em;
font-weight: bold;
}

.arthas form input {
font-family: Arial Helvetica, sans-serif;
font-size: 1.1em;
font-weight: bold;
padding: 5px;
border: 1px solid #c0d6ea;
background: #f6fbff;
margin-bottom: 10px;
color: #122d40;
}

.signup {
width: 300px;
}
-->
</style>
<script type="text/javascript" src="../js/flashembed.js"></script>
<script type="text/javascript" src="../js/dropdown.js"></script>
</head>
<body>
<div id="container">
<div id="header"></div>
<div id="navigation">
<ul>
<li><a href="http://www.zygorguides.com" onclick="" onmouseover="dropdownmenu(this, event, menu1, '150px')" onmouseout="delayhidemenu()">Home</a></li>
<li><a href="../news/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu2, '150px')" onmouseout="delayhidemenu()">News</a></li>
<li><a href="../about/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu3, '150px')" onmouseout="delayhidemenu()">About</a></li>
<li><a href="../guides/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu4, '150px')" onmouseout="delayhidemenu()">Guides</a></li>
<li><a href="index.php" onclick="" onmouseover="dropdownmenu(this, event, menu5, '150px')" onmouseout="delayhidemenu()">Free Trial</a></li>
<li><a href="../amember/member.php" onclick="" onmouseover="dropdownmenu(this, event, menu6, '150px')" onmouseout="delayhidemenu()">Members Area</a></li>
<li><a href="../forum/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu7, '150px')" onmouseout="delayhidemenu()">Forum</a></li>
<li><a href="../faq/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu8, '150px')" onmouseout="delayhidemenu()">FAQ</a></li>
<li><a href="../contact/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu9, '150px')" onmouseout="delayhidemenu()">Contact</a></li>
</ul>
</div>
<div id="content">
<div id="main">
  <p><img src="../img/trialguide.jpg" alt="alliance sample" width="500" height="54" class="imageborder" /></p>
<p>We believe that the difference in quality you will find in our guides over our competitors is better experienced than simply talked about. We also know that many of you would prefer to try the guides out before buying them. That is why we now offer a free 1-13 trial version of our Alliance and Horde guides.</p>
<p>This is a fully functional version of our guide and are only limited in regards to the max level you can achieve with them. Our all new In-Game Talent Advisor is also included which will instruct you on where to spend your talent points when you level up.</p>
<p> To recieve your copy of the Free Trial Guide simply enter your email in the form below and a download link will be sent to you. If you are interested in trying the Alliance guide as well, hover over Freebies in the above navigation bar and select Alliance Guide Sample.</p>
<div class="arthas">
<form method="post" action="http://www.aweber.com/scripts/addlead.pl">
<input type="hidden" name="meta_web_form_id" value="764917112">
<input type="hidden" name="meta_split_id" value="">
<input type="hidden" name="unit" value="zygortrial">
<input type="hidden" name="redirect" value="http://www.aweber.com/form/thankyou_vo.html" id="redirect_3be9e1cb2050fdd30e08fbcdd8a4bdde">
<input type="hidden" name="meta_redirect_onlist" value="">
<input type="hidden" name="meta_adtracking" value="">
<input type="hidden" name="meta_message" value="1">
<input type="hidden" name="meta_required" value="from">
<input type="hidden" name="meta_forward_vars" value="0">
<img src="../img/downloadlink.png" />
<input type="text" value="Name" onclick="this.value='';" onfocus="this.select()" onblur="this.value=!this.value?'Enter Your Name':this.value;" name="name" size="20"><br />
<input type="text" value="Enter Your Email" onclick="this.value='';" onfocus="this.select()" onblur="this.value=!this.value?'Enter Email Address':this.value;" name="from" size="20"><br />
<input type="submit" name="submit" value="Submit">
<img src="http://forms.aweber.com/form/displays.htm?id=7GwsnIzsjIxM" border="0" />
</form>


</div>

<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
<br />

</div>
</div>
<div id="sidebar">
<div class="feedbox">
<h2>Subscribe:</h2>
<form method="post" action="http://www.aweber.com/scripts/addlead.pl">
<input type="hidden" name="meta_web_form_id" value="1486465894">
<input type="hidden" name="meta_split_id" value="">
<input type="hidden" name="unit" value="zygorguides">
<input type="hidden" name="redirect" value="http://www.aweber.com/form/thankyou_vo.html" id="redirect_56c3aaf87f8c201c3fd33ea0bde91a78">
<input type="hidden" name="meta_redirect_onlist" value="">
<input type="hidden" name="meta_adtracking" value="">
<input type="hidden" name="meta_message" value="1">
<input type="hidden" name="meta_required" value="from">
<input type="hidden" name="meta_forward_vars" value="0">
<label><em>We respect your privacy</em></label>
<input type="text" value="Enter Your Email" onclick="this.value='';" onfocus="this.select()" onblur="this.value=!this.value?'Enter Email Address':this.value;" name="from" size="20">
<div class="buttonarea">
<input type="submit" name="submit" value="Sign Up">
</div>
</form>
<div class="center">
<p>Sign up to our newsletter for free guides, tips and important news regarding our products</p>
</div>
</div>


<div class="sidebox">
<script src="http://widgets.twimg.com/j/2/widget.js"></script>
<script>
new TWTR.Widget({
  version: 2,
  type: 'profile',
  rpp: 4,
  interval: 6000,
  width: 220,
  height: 300,
  theme: {
    shell: {
      background: '#4589ab',
      color: '#252525'
    },
    tweets: {
      background: '#ffffff',
      color: '#252525',
      links: '#213c57'
    }
  },
  features: {
    scrollbar: true,
    loop: false,
    live: false,
    hashtags: true,
    timestamp: true,
    avatars: false,
    behavior: 'all'
  }
}).render().setUser('zygorguides').start();
</script>
</div>

<div class="sidebox">
<h2>Recent Forum Posts:</h2>
<div id="topics">
<div class="darkbox">
<div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3315&goto=newpost'>Blood Elf Paladin Quests</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 01:35 PM </span></p></div><div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3313&goto=newpost'>Suggestion</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 12:03 PM </span></p></div><div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3312&goto=newpost'>Blood Elf Hunter</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 10:23 AM </span></p></div><div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3310&goto=newpost'>Guides resetting each time I start WOW</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 06:26 AM </span></p></div></div></div>
<img src="../img/gnomeposts.png" /></img>
</div>



</div><div id="footer">
<p><a href="http://www.zygorguides.com">Home</a> | <a href="http://www.zygorguides.com/news/index.php">News</a> | <a href="http://www.zygorguides.com/about/index.php">About</a> | <a href="http://www.zygorguides.com/guides/index.php">Guides</a> | <a href="http://www.zygorguides.com/freebies/index.php">Freebies</a> | <a href="http://www.zygorguides.com/amember/member.php">Members Area</a> | <a href="http://www.zygorguides.com/forum/index.php">Forum</a> | <a href="http://www.zygorguides.com/faq/index.php">FAQ</a> | <a href="http://www.zygorguides.com/contact/index.php">Contact</a> | <a href="http://www.zygorguides.com/affiliates/index.php">Affiliates</a></p></div>
</body>