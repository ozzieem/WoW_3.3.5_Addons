<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--
##  Zygor Guides | version 1.0 | "PEACH"
##  [ www.zygorguides.com ] [ www.tikitula.com ]
##
##  All contents within are Copyright © 2008, Zygor Guides LLC & The Tiki Tula.
##  All Rights Reserved ® 
-->
<head>
<title>Zygor Guides</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="The #1 best-selling in-game World of Warcraft leveling guides." />
<meta name="keywords" content="world of warcraft guide, world of warcraft leveling, wow leveling guide, alliance leveling guide, horde leveling guide, 1-80 leveling guide, in game leveling guides" />
<meta name="language" content="en-us, english" />
<meta name="classification" content="Blog" />
<meta name="author" content="Andrew Sturgeon" />
<meta name="copyright" content="Zygor Guides LLC" />
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="alternate" type="application/rss+xml" title="The Zygor Guides News Feed" href="http://feeds.feedburner.com/zygorguides" />
<style type='text/css' media='screen'>
<!--
@import url(../css/peach.css);
-->
</style>
<script type="text/javascript" src="../js/flashembed.js"></script>
<script type="text/javascript" src="../js/dropdown.js"></script>
<script type="text/javascript" src="../js/prototype.js"></script>
<script type="text/javascript" src="../js/scriptaculous.js"></script>
</head>
<body>
<div id="container">
<div id="header"></div>
<div id="navigation">
<li><a href="http://www.zygorguides.com" onclick="" onmouseover="dropdownmenu(this, event, menu1, '150px')" onmouseout="delayhidemenu()">Home</a></li>
<li><a href="../news/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu2, '150px')" onmouseout="delayhidemenu()">News</a></li>
<li><a href="../about/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu3, '150px')" onmouseout="delayhidemenu()">About</a></li>
<li><a href="../guides/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu4, '150px')" onmouseout="delayhidemenu()">Guides</a></li>
<li><a href="../freetrial/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu5, '150px')" onmouseout="delayhidemenu()">Free Trial</a></li>
<li><a href="../amember/member.php" onclick="" onmouseover="dropdownmenu(this, event, menu6, '150px')" onmouseout="delayhidemenu()">Members Area</a></li>
<li><a href="../forum/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu7, '150px')" onmouseout="delayhidemenu()">Forum</a></li>
<li><a href="index.php" onclick="" onmouseover="dropdownmenu(this, event, menu8, '150px')" onmouseout="delayhidemenu()">FAQ</a></li>
<li><a href="../contact/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu9, '150px')" onmouseout="delayhidemenu()">Contact</a></li>
</div>
<div id="content">
<div id="main">
<div class="bigtext">FAQ</div>
<h3>Guides</h3>
<span class="question"><a href="##" onclick="Effect.toggle('0','Slide', {duration: 0.3});">What makes your guides better than the guides I've seen other people selling?</a></span>
<div id="0" style="display:none">
<div class="answer">It is our policy to set the bar for our products extremely high. We like the challenge of making our guides address the individual needs of gamers no matter how difficult or complex. The difference in quality found in our products is what sets us apart, and we believe this difference is better experienced than talked about, which is why we will soon be offering free trial demos for download. In the meantime, you can find a comparison video and chart of all the major guides on the market over <a href="http://www.zygorguides.com/index.php#chart">here</a>.</div>
</div>

<span class="question"><a href="##" onclick="Effect.toggle('1','Slide', {duration: 0.3});">What makes your guide different than Quest Helper?</a></span>
<div id="1" style="display:none">
<div class="answer">Unlike Quest Helper, which only takes quests in your log and tries to order them in the best way, our guide gives you a direct path of the best quests while allowing you to avoid picking up needless quests that don't yeild much experience. You also get detailed information on how to actually complete the quests.</div>
</div>

<span class="question"><a href="##" onclick="Effect.toggle('2','Slide', {duration: 0.3});">Can I use the guide if I'm playing a character that is already partially leveled or do I have to start a new character from scratch?</a></span>
<div id="2" style="display:none">
<div class="answer">It's easy to just pick up our guide and start playing, no matter where you are in the game. Usually, all you have to do is to start the guide about 2 levels below your current level to get on track with our quest path.</div>
</div>

<span class="question"><a href="##" onclick="Effect.toggle('3','Slide', {duration: 0.3});">Will you be releasing Wrath of the Lich King Guides that cover levels 70-80?</a></span>
<div id="3" style="display:none">
<div class="answer">Yes! Zygor Guides will be releasing 1-80 Alliance and Horde Leveling Guides guides and 70-80 guide expansions for previous customers on November 13th, 2008 (the official release date of WotLK). For more information, head over to our <a href="../guides/wotlk.php">Wrath of the Lich King section</a>.</div>
</div>

<span class="question"><a href="##" onclick="Effect.toggle('4','Slide', {duration: 0.3});">What do you mean when you say the guides come with "free updates for life"?</a></span>
<div id="4" style="display:none">
<div class="answer">Free updates for life refers to changes made to the game through patches. The guides are often reworked to take advantage of any changes that could increase the effectiveness of our guides. These updates are 100% free of charge. World of Warcraft Expansions such as <i>The Burning Crusade</i> and <i>Wrath of the Lich King</i> are considered seperate games, and as such, they require a small upgrade fee for the guide expansion. </div>
</div>

<span class="question"><a href="##" onclick="Effect.toggle('5','Slide', {duration: 0.3});">Are your guides updated for Patch 3.1.3.?</a></span>
<div id="5" style="display:none">
<div class="answer">Our guides have been revised and updated for Patch 3.1.3. as of April 15th, 2009.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('6','Slide', {duration: 0.3});">I'm having trouble installing the guide. Where can I get help?
</a></span>
<div id="6" style="display:none">
<div class="answer">You can find a complete written walkthrough of how to install the guide on our <a href="../members/support.php">Technical Support page</a>.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('7','Slide', {duration: 0.3});">Are your guides compatible with Macs?</a></span>
<div id="7" style="display:none">
<div class="answer">Our guides are fully compatible with both Windows and Mac versions of World of Warcraft.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('8','Slide', {duration: 0.3});">Do the guides cover all of the races?</a></span>
<div id="8" style="display:none">
<div class="answer">The guide covers the starter areas of all 10 races. The guide will automatically detect what race you are and display the corresponding starter guide.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('9','Slide', {duration: 0.3});">Can any class use your guides, or does it only work with Hunters?</a></span>
<div id="9" style="display:none">
<div class="answer">Unlike other guides, which rely on the faster leveling of Hunters to work, our guide is designed to be used easily by all classes.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('10','Slide', {duration: 0.3});">Will my account get banned if I use your guide?</a></span>
<div id="10" style="display:none">
<div class="answer">Absolutely not. Our in-game mod complies with Blizzards policies regarding modifications to the game. Your account will not get banned.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('11','Slide', {duration: 0.3});">Are your guides available in any other languages besides English?</a></span>
<div id="11" style="display:none">
<div class="answer">We are working on translating the guides into other languages. We will be releasing German, French, and Russian versions of the guide within the next few months.</div>
</div>

<span class="question"><a href="##" onclick="Effect.toggle('12','Slide', {duration: 0.3});">Will you be lowering the price of the guides anytime soon?</a></span>
<div id="12" style="display:none">
<div class="answer">No. However, we may have discounted offers periodically throughout the year. To stay up to date on such announcements, please subscribe to our newsletter on the right.</div>
</div>
<div class="spacer"></div>

<h3>Website</h3>
<span class="question"><a href="##" onclick="Effect.toggle('13','Slide', {duration: 0.3});">What's going on with the website? It looks different.</a></span>
<div id="13" style="display:none">
<div class="answer">Our site has been completely redesigned from the ground up with to offer members an potentional customers and asethically pleasing interface that is easier to navigate and use.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('14','Slide', {duration: 0.3});">Will my information on this site be kept private?</a></span>
<div id="14" style="display:none">
<div class="answer">Your privacy is very important to us. Click <a href="privacy.php">here</a> to read our Privacy Policy or <a href="http://www.zygorguides.com/faq/tos.php">here</a> to read our Terms of Service.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('15','Slide', {duration: 0.3});">Why can't I post on the forums?</a></span>
<div id="15" style="display:none">
<div class="answer">Posting is a priviledge granted only to members. However, anyone can read the forums.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('16','Slide', {duration: 0.3});">How do I change my username on the forums?</a></span>
<div id="16" style="display:none">
<div class="answer">You can change your account info, including your username, inside the <a href="http://www.zygorguides.com/amember/member.php">members area</a>. Simply login and click <a href="">Change Password/Edit Profile</a>.</div>
</div>
<span class="question"><a href="##" onclick="Effect.toggle('17','Slide', {duration: 0.3});">What should I do if I find a broken link on the site?</a></span>
<div id="17" style="display:none">
<div class="answer">To help improve the site, please send any information about site errors or broken links to us by using our <a href="../contact/index.php">contact page</a>.</div>
</div>
<div class="spacer"></div><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
</div>
</div>
<div id="sidebar">
<div class="feedbox">
<h2>Subscribe:</h2>
<form method="post" action="http://www.aweber.com/scripts/addlead.pl">
<input type="hidden" name="meta_web_form_id" value="1486465894">
<input type="hidden" name="meta_split_id" value="">
<input type="hidden" name="unit" value="zygorguides">
<input type="hidden" name="redirect" value="http://www.aweber.com/form/thankyou_vo.html" id="redirect_56c3aaf87f8c201c3fd33ea0bde91a78">
<input type="hidden" name="meta_redirect_onlist" value="">
<input type="hidden" name="meta_adtracking" value="">
<input type="hidden" name="meta_message" value="1">
<input type="hidden" name="meta_required" value="from">
<input type="hidden" name="meta_forward_vars" value="0">
<label><em>We respect your privacy</em></label>
<input type="text" value="Enter Your Email" onclick="this.value='';" onfocus="this.select()" onblur="this.value=!this.value?'Enter Email Address':this.value;" name="from" size="20">
<div class="buttonarea">
<input type="submit" name="submit" value="Sign Up">
</div>
</form>
<div class="center">
<p>Sign up to our newsletter for free guides, tips and important news regarding our products</p>
</div>
</div>


<div class="sidebox">
<script src="http://widgets.twimg.com/j/2/widget.js"></script>
<script>
new TWTR.Widget({
  version: 2,
  type: 'profile',
  rpp: 4,
  interval: 6000,
  width: 220,
  height: 300,
  theme: {
    shell: {
      background: '#4589ab',
      color: '#252525'
    },
    tweets: {
      background: '#ffffff',
      color: '#252525',
      links: '#213c57'
    }
  },
  features: {
    scrollbar: true,
    loop: false,
    live: false,
    hashtags: true,
    timestamp: true,
    avatars: false,
    behavior: 'all'
  }
}).render().setUser('zygorguides').start();
</script>
</div>

<div class="sidebox">
<h2>Recent Forum Posts:</h2>
<div id="topics">
<div class="darkbox">
<div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3315&goto=newpost'>Blood Elf Paladin Quests</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 01:35 PM </span></p></div><div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3313&goto=newpost'>Suggestion</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 12:03 PM </span></p></div><div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3312&goto=newpost'>Blood Elf Hunter</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 10:23 AM </span></p></div><div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3310&goto=newpost'>Guides resetting each time I start WOW</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 06:26 AM </span></p></div></div></div>
<img src="../img/gnomeposts.png" /></img>
</div>



</div><div id="footer"><p><a href="http://www.zygorguides.com">Home</a> | <a href="http://www.zygorguides.com/news/index.php">News</a> | <a href="http://www.zygorguides.com/about/index.php">About</a> | <a href="http://www.zygorguides.com/guides/index.php">Guides</a> | <a href="http://www.zygorguides.com/freebies/index.php">Freebies</a> | <a href="http://www.zygorguides.com/amember/member.php">Members Area</a> | <a href="http://www.zygorguides.com/forum/index.php">Forum</a> | <a href="http://www.zygorguides.com/faq/index.php">FAQ</a> | <a href="http://www.zygorguides.com/contact/index.php">Contact</a> | <a href="http://www.zygorguides.com/affiliates/index.php">Affiliates</a></p></div>
</div>
</body>