<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--
##  Zygor Guides | version 1.0 | "PEACH"
##  [ www.zygorguides.com ] [ www.tikitula.com ]
##
##  All contents within are Copyright © 2008, Zygor Guides LLC & The Tiki Tula.
##  All Rights Reserved ® 
-->
<head>
<title>Zygor Guides</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="The #1 best-selling in-game World of Warcraft leveling guides." />
<meta name="keywords" content="world of warcraft guide, world of warcraft leveling, wow leveling guide, alliance leveling guide, horde leveling guide, 1-80 leveling guide, in game leveling guides" />
<meta name="language" content="en-us, english" />
<meta name="classification" content="Blog" />
<meta name="author" content="Andrew Sturgeon" />
<meta name="copyright" content="Zygor Guides LLC" />
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="alternate" type="application/rss+xml" title="The Zygor Guides News Feed" href="http://feeds.feedburner.com/zygorguides" />
<style type='text/css' media='screen'>
<!--
@import url(../css/peach.css);
#content {
width: 790px;
}

#main {
padding: 50px;
padding-top: 20px;
}

.talents {
list-style-type: none;
}

.talents li {
margin-left: 25px;
font-size: 1.1em;
line-height: 1.5em;
}

textarea {
		background: #e2d3ca;
		border: 1px solid #333;
		font-family: Georgia, Helvetica, sans-serif;
		font-size: 0.9em;
		color: #000;
		padding: 2px;
		padding-bottom: 1px;
		}



-->
</style>
<script type="text/javascript" src="../js/flashembed.js"></script>
<script type="text/javascript" src="../js/dropdown.js"></script>
<script src="http://www.wowhead.com/widgets/power.js"></script>
</head>
<body>
<div id="container">
<div id="header"></div>
<div id="navigation">
<ul>
<li><a href="http://www.zygorguides.com" onclick="" onmouseover="dropdownmenu(this, event, menu1, '150px')" onmouseout="delayhidemenu()">Home</a></li>
<li><a href="../news/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu2, '150px')" onmouseout="delayhidemenu()">News</a></li>
<li><a href="../about/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu3, '150px')" onmouseout="delayhidemenu()">About</a></li>
<li><a href="../guides/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu4, '150px')" onmouseout="delayhidemenu()">Guides</a></li>
<li><a href="../freetrial/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu5, '150px')" onmouseout="delayhidemenu()">Freebies</a></li>
<li><a href="../amember/member.php" onclick="" onmouseover="dropdownmenu(this, event, menu6, '150px')" onmouseout="delayhidemenu()">Members Area</a></li>
<li><a href="../forum/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu7, '150px')" onmouseout="delayhidemenu()">Forum</a></li>
<li><a href="../faq/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu8, '150px')" onmouseout="delayhidemenu()">FAQ</a></li>
<li><a href="../contact/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu9, '150px')" onmouseout="delayhidemenu()">Contact</a></li>
</ul>
</div>
<div id="content">
<div id="main">
<div class="bigtext">Auction Appraiser Guide</div>
<h3><img src="../img/Orc_Peon_Face_Coin.jpg" alt="dk" class="imageleft" />Overview</h3>
<p>Lots of guides show you how to make gold in the game, but they tell you things that really cut into your leveling time. This guide is intended to show you ways to make lots of gold WHILE leveling your characters. The information in this guide will help you on your way to buying your talents, gear, and mounts on your way to level 80. So without further adue, lets get started.<br />
  <br />
</p>

<h3>Getting your upstart</h3>
<p>We will start off with the basics of how to collect a decent pile of coins in the earliest stages of World of Warcraft. If you already have another character who can send you money then you do not need to read this section, unless you're just curious.</p>
<h2>Auction House Alt</h2>
<p>After you create your new character you should begin leveling straight away, right? Actually, the first thing you should do is create another character and run them all the way to the nearest major city. For Alliance, we recommend making a Dwarf/Gnome and running them to Ironforge. For Horde, make an Orc/Troll and run them to Orgrimmar. Make their name something short and easy to remember because whenever you need to sell things at the Auction House or send things to your main character you will use this character. You don't want the name to be long to type of hard to remember when you send stuff to the alt via the mailbox.</p>
<p>Now that you have your alt character, start questing with you main. At the beginning you will get a lot of trash items and should basically sell these items to vendors to start generating money. We recommend the addon <a href="http://wow.curse.com/downloads/wow-addons/details/sell-o-matic.aspx">Sell-O-Matic</a> which will place a single button on the vendor sell screen that automatically sells all gray items for you.</p>
<p>Eventually you will start getting Small Eggs, Stringy Wolf Meat, and Chunks of Boat Meat off mobs. Send these to your alt to sell on the Auction House. They pretty much always sell regardless of the servers economy.</p>
<h2>Bigger Bags</h2>
<p>One of the few things that it is ok to spend your money on is more inventory space (Bags). Most of the stuff you can make money on while leveling is collected while questing, so the bigger the bags the better the haul you can ship to your Auction House Alt.</p>
<h2>Do Not Buy Gear!</h2>
<p>One of the biggest money sinks in the game is actually a players own compulsive nature to spend, spend, spend at every oppurtunity, especially when it comes to gear. When using Zygor's Guide you will level up so quickly that the gear you buy will become outdated very fast. The gear you get for rewards should suffice for the most part. Only buy gear if you start having a hard time killing mobs or surviving in fights. We recommend buying a new gear only every 10 levels or even longer if you can manage.</p>
<h2>Do Not Buy Every Spell</h2>
<p>A lot of players have the bad habit of going to their class trainers every two levels and buying every new talent that is available to them. Generally, this is not nessasary since only a handful of talents have real use while leveling.
<h2>Get Two Gathering Professions</h2>
<p>The only professions worth considering until you reach 80 are the three gathering professions: Skinning, Herbalism, and Mining. We recommend taking at least Skinning because it skills up faster and you get more skins than you will herbs or minerals. Sell all your stacks on the Auction House.<br />
</p>
<h3>Auctioneer Appraiser Overview:</h3>
<p>Auctioneer is one of the best addons available for World of Warcraft and is crucial to making money in the game. Have you ever found an item or a stack of items and gone to the Auction House only to discover you had no idea how much the items you collected were worth? Well this guide will demonstrate how you can use Auctioneer to set prices for your items and have it automatically undercut any competition you may have from other payers selling the same items. The first thing you will need to do is download and install the Auctioneer addon (it's free!) onto your computer.</p>
<h3>Download and Installation:</h3>
  <p><strong><img src="../img/Auctioneer1.png" alt="auctioneer" width="300" height="218" class="imgright" />01)</strong> Type <a href="http://auctioneeraddon.com/"><strong>http://auctioneeraddon.com/</strong></a> into the address bar of your internet browser and press enter</p>
  <p><strong>02)</strong> On the Auctioneer homepage, select Download</p>
  <p><strong>03)</strong> You will be asked which version of Auctioneer you will want to download. Choose the latest Release Version.</p>
  <p><strong>04)</strong> On this next screen you will be given the option to download various packages that bundle Auctioneer with a few other addons. For this guide you will need the AuctioneerSuite package which is the first item down from the top of the page. You should see a section labled by Filename/Date/Size/Quality. Click the download link that says <a href="http://auctioneeraddon.com/dl/#release"><strong>AuctioneerSuite-VersionNumber.zip</strong></a> underneath Filename.</p>
  <p><strong>05)</strong> A dialog box should pop up asking you if you want to open the download or save it to your harddrive. Because sometimes there are problems with opening directly from a download we recommend that you save the file to your desktop first before proceeding.</p>
  <p><strong>06)</strong> The next step can be done either using the extraction tools built into Windows XP/Vista or with a program like WinRar or WinZip. The easiest way would be to install WinRar and then right click the file you downloaded to your desktop and select extract here. This should unzip the folders directly onto your desktop. After that, head over to your World of Warcraft directory, go into Interface/Addons, then drag and drop the folders from your desktop to the addons folders. </p>
  <p>Another way would be to right click the zip package and click Extract files, then set the Destination path to your addons folder.</p>
  <p>If you do not have WinRar then you can use the extraction function built into Windows XP/Vista. Double click the file on your desktop and you should either see an option to Extract All Files on the left hand side of the window underneath Folder Tasks, click that and the Extraction Wizard will pop up. Click Next. Then it will ask you where you want to extract the files.</p>
  <p>Usually the addons folder is found in the following locations by default</p>
  <p><strong>Windows XP:</strong><br />
    C: -&gt; Program Files -&gt; World of Warcraft -&gt; Interface -&gt; AddOns</p>
  <p><strong>Windows Vista:</strong><br />
    C: -&gt; Users -&gt; Public -&gt; Games -&gt; World of Warcraft -&gt; Interface -&gt; AddOns</p>
  <p><strong>OSX:</strong><br />
    Applications -&gt; World of Warcraft -&gt; Interface -&gt; AddOns</p>
  <p><strong>07)</strong> Launch World of Warcraft. If you installed everything in the proper place you should see Auctioneer listed under the addons button when you go to the character selection screen. If you do not see it you need to go back through the steps and find out where you went wrong. If you are having trouble locating your addon directory then an easy to find it is to right click your World of Warcraft shortcut on your desktop and select Properties. The directory will be listed next to the word Target.</p>
  <p>To find out if Auctioneer is installed correctly and is working properly head to the nearest Auction House and talk to one of the Auctioneers. You should see new tabs at the bottom like BeanCounter and Appraiser.</p>
  <p><strong>08)</strong> Congratulations you have succesfully installed Auctioneer!<br />
  </p>
  <p>&nbsp;</p><br />
<h3>Selling Items With Appraiser:</h3>
<p>Auctioneer is useful for many purposes. One of the best uses of it is deciding which item to choose for a Quest Reward. Say you have four items to choose from but none of the items are that useful to your character, or maybe you just already have better items. By hovering over each of the items you will now see two windows pop up, the standard WoW Window, and a new Auctioneer window with lots of information. You should usually see a stat called &quot;Sell to vendor&quot; or just &quot;Sell&quot; which will tell you which of the items will be worth the most gold if you decide to sell it.<br />
  <br />
</p>
<p align="center"><img src="../img/Auctioneer2.png" alt="auctioneer2" width="250" height="333" class="imageborder" /><br />
  <br />
</p>
<p>
  When your bags get filled and/or you are ready to sell your items, head to the nearest Auction House and talk to an Auctioneer. The Auctioneer addon makes it really easy to find the items in your bags that you can actualy sell. At the bottom of the Auction House Interface select the Appraiser tab. On the left side of the interface you will see a list of all the items you can sell and how many duplicates of that item you have. For this demonstration I'm going to sell a stack of Netherweave Cloth. <br />
  <br />
</p>
<p align="center"><img src="../img/auct3.png" alt="auct3" width="500" height="271" class="imageborder" /><br />
  <br />
</p>
<p>Before we can sell the items we need to set some parameters first. It's best to sell items in stacks of 20 if possible. I have 27 Netherweave Cloth which means I really only have one stack to sell. Since I want to be able to keep adding to the extra 7 I need to tell Auctioneer not to sell the remaining 7. To do this, move the stack size meter to 20. This tells Auctioneer how much of a certain item should be considered a single stack. If you set it to 10 then it will think having 10 Netherweave Cloth is a full stack and will sell 2 stacks of 10 if you had 27 pieces like I do in this demonstration. <br />
  <br />
  Next you need to tell Auctioneer how many stacks you want it to sell. If you set it to &quot;All&quot; it will sell not only the complete stacks but any extra pieces of an item you have, which we don't want it to do. So set the meter to Full, that way it only sells the item if it has a complete stack, and doesn't sell incomplete stacks. Finally, make sure the Duration is set to 48 hours so you have the best chance of selling your items.<br />
  <br />
</p>
<p align="center"><img src="../img/auct1.png" alt="auct1" width="500" height="270" class="imageborder" /><br />
  <br />
</p>
<p>Now without Auctioneer I would just have to guess how much a stack of Netherweave Cloth was worth, but with Auctioneer I will know exactly what it is worth. If you look on the right side you should see two rows that say Bid and Buy per item respectively, followed by a price. After clicking what you want to sell (in this case, Netherweave Cloth), set the Pricing model to &quot;market&quot; and hit the Refresh button at the bottom of the page. Auctioneer will scan the Auction House for other players selling the same item, find out how much the item is going for, then it will calculate the best price to sell it for, usually undercutting the competition by around 5% so that yours has a higher chance to sell. <br />
  <br />
  Once you have a price, press the Post Items button and it will begin selling. What's really cool is that if you have say 100 Netherweave Cloth, it will automatically sell all 5 stacks back to back. You don't have to keep selling each stack individually which savess a great deal of time.<br />
  <br />
</p>
<p align="center"><img src="../img/auct2.png" alt="auct2" width="500" height="270" class="imageborder" /><br />
  <br />
</p>
<p>To check on the Auctions you have up just click the Auctions tab at the bottom of the Auction House Interface.</p>
</div>
</div>
<div id="footer">
  <p>Copyright © 2009 Zygor Guides, LLC. All Rights Reserved.</p>
</div>
</div>
</body>
</html>