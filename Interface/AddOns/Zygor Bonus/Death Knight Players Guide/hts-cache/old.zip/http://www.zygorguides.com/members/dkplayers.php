<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--
##  Zygor Guides | version 1.0 | "PEACH"
##  [ www.zygorguides.com ] [ www.tikitula.com ]
##
##  All contents within are Copyright © 2008, Zygor Guides LLC & The Tiki Tula.
##  All Rights Reserved ® 
-->
<head>
<title>Zygor Guides</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="The #1 best-selling in-game World of Warcraft leveling guides." />
<meta name="keywords" content="world of warcraft guide, world of warcraft leveling, wow leveling guide, alliance leveling guide, horde leveling guide, 1-80 leveling guide, in game leveling guides" />
<meta name="language" content="en-us, english" />
<meta name="classification" content="Blog" />
<meta name="author" content="Andrew Sturgeon" />
<meta name="copyright" content="Zygor Guides LLC" />
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="alternate" type="application/rss+xml" title="The Zygor Guides News Feed" href="http://feeds.feedburner.com/zygorguides" />
<style type='text/css' media='screen'>
<!--
@import url(../css/peach.css);
.style2 {color: #006633}
.style4 {color: #800000}
.style6 {color: #663399}
.style7 {color: #003366}
#content {
width: 790px;
}

#main {
padding: 50px;
padding-top: 20px;
}

.talents {
list-style-type: none;
}

.talents li {
margin-left: 25px;
font-size: 1.1em;
line-height: 1.5em;
}

.style16 {color: #800000}

textarea {
		background: #e2d3ca;
		border: 1px solid #333;
		font-family: Georgia, Helvetica, sans-serif;
		font-size: 0.9em;
		color: #000;
		padding: 2px;
		padding-bottom: 1px;
		}
.style23 {
	font-size: 14px;
	font-weight: bold;
}



-->
</style>
<script type="text/javascript" src="../js/flashembed.js"></script>
<script type="text/javascript" src="../js/dropdown.js"></script>
</head>
<body>
<div id="container">
<div id="header"></div>
<div id="navigation">
<ul>
<li><a href="http://www.zygorguides.com" onclick="" onmouseover="dropdownmenu(this, event, menu1, '150px')" onmouseout="delayhidemenu()">Home</a></li>
<li><a href="../news/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu2, '150px')" onmouseout="delayhidemenu()">News</a></li>
<li><a href="../about/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu3, '150px')" onmouseout="delayhidemenu()">About</a></li>
<li><a href="../guides/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu4, '150px')" onmouseout="delayhidemenu()">Guides</a></li>
<li><a href="index.php" onclick="" onmouseover="dropdownmenu(this, event, menu5, '150px')" onmouseout="delayhidemenu()">Freebies</a></li>
<li><a href="../amember/member.php" onclick="" onmouseover="dropdownmenu(this, event, menu6, '150px')" onmouseout="delayhidemenu()">Members Area</a></li>
<li><a href="../forum/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu7, '150px')" onmouseout="delayhidemenu()">Forum</a></li>
<li><a href="../faq/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu8, '150px')" onmouseout="delayhidemenu()">FAQ</a></li>
<li><a href="../contact/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu9, '150px')" onmouseout="delayhidemenu()">Contact</a></li>
</ul>
</div>
<div id="content">
<div id="main">
<div class="bigtext">Death Knight Players Guide</div>
<img src="http://www.zygorguides.com/img/deathknight.jpg" alt="dk" class="imageleft" />
<h3>Death Knight Overview:</h3>
<p>The Death Knight is the first new class addition to World of Warcraft in four years. The class features an all new runic fighting system, a new starter area, and to top it off, an amazing class quest line that ends in truely epic way. There is something for everyone offered in the Death Knight Class.  Whether you want to be able to heal yourself, deal massive DPS, or take on hordes of enemies with AoE damage, your Death Knight has the ability to do so. Any race can play as a Death Knight, but to unlock the class, players must have a character level 55 or above already made on a realm. Once the class is unlocked for the account, a death knight can be created on any realm where the player has a level 55 or higher character. Blizzard plans to relax the restriction and allow creation on all realms at some point after release.</p>

<p>The death knight starts at level 55 in Acherus: The Ebon Hold over the Eastern Plaguelands, with multiple spells and abilities ready to use, and a set of uncommon gear.</p>

<h3>Rune System:</h3>
<p>The death knight uses a unique rune-based resource system to use their spells and abilities. Three rune types: Blood, Frost, and Unholy, each with an attached color and symbol. As they use an an ability, the runes needed for that ability will undergo a cooldown period before they can be used again (10 seconds). The Death Knight will be able to use spells to turn a rune into a Death Rune, which can be used as a Blood/Frost/Unholy rune. In addition, whenever the Death Knight uses a rune ability against a foe, it will build up a certain amount of Runic Power. Runic Power can be used for special finisher attacks. Death Knight's also get the Runeforging skill, which allows the player to enchant their weapons. Death Knights learn Runeforging in the start area, after a few quests. When near a Runeforge you will be able to click a spell in your spell book, just like enchanting, and then choose an "enchant" to perform on the weapon. Runeforging will overwrite enchants.</p>

<p>Currently there are 8 different 'enchants' you can place on your weapon.</p>

<ul class="runelist">
<li><strong>Rune of Cinderglacier</strong>: Affixes your rune weapon with a rune that has a chance to increase the damage by 20% for your next 2 attacks that deal Frost or Shadow damage. This is what you will want to use on your weapon throughout the starter area portion of the game (55-58)</li>
<li><strong>Rune of Lichbane</strong>: Affixes your rune weapon with a rune that adds 2% extra weapon damage as Fire damage or 4% versus Undead targets. This is what you will want to use on your weapons in the plaguelands, as there are plenty of undeads.</li>
<li><strong>Rune of Razorice</strong>: Affixes your rune weapon with a rune that adds 2% extra weapon damage as Frost damage and has a chance to increase Frost vulnerability. This is what you will want to use in Outland.</li>
<li><strong>Rune of Spellbreaking</strong>: Affixes your rune weapon with a rune that deflects 2% of all spell damage and reduces the duration of Silence effects by 50%.</li>
<li><strong>Rune of Spellshattering</strong>: Affixes your rune weapon with a rune that deflects 4% of all spell damage and reduces the duration of Silence effects by 50%.</li>
<li><strong>Rune of Swordbreaking</strong>: Affixes your rune weapon with a rune that increases Parry chance by 2% and reduces the duration of Disarm effects by 50%.</li>

<li><strong>Rune of Swordshattering</strong>: Affixes your rune weapon with a rune that increases Parry chance by 4% and reduces the duration of Disarm effects by 50%.</li>
<li><strong>Rune of the Fallen Crusader</strong>: Affixes your rune weapon with a rune that has a chance to heal you for 3% and increase total strength by 30% for 15 sec. This is what you will want to use in Northrend.</li>
</ul>

<h3>Class Role:</h3>
<p>In general, the death knight can be considered a hybrid class that combines damage dealing and tanking. They will wear plate armor, and be able to dual wield or use two-handed blade weapons and maces. Like druids, they will tank without shields. Their tanking mechanics will most likely be high armor as indicated by Frost Presence, and by having a high chance to parry. Blizzard has said that their tanking niche will be caster-type enemies. A common assumption among fans is that Hero Classes will be overpowered, however Blizzard has stated on announcing the Death Knight that they will be of similar strength and value to existing classes.</p>

<h3>Playing as a Death Knight:</h3>
<p>As you quest in the starter area, you will want to runeforge your weapons with Rune of Cinderglacier. The best weapons for leveling are two handed swords, axes and maces. Generally the best spell rotation involves using a Frost spell, an Unholy spell, a blood spell twice, repeating the chain as many times as nessasary, and then closing the battle with a finishing runic power spell.</p>

<p>The most basic rotation is:</p>

<p><span class="style7"><span class="style6">Death Grip</span> <img src="../img/finisher.png" alt="unholy" /> Icy Touch</span> <img src="../img/frost.png" /> | <span class="style2">Plague Strike</span> <img src="../img/unholy.png" /> | <span class="style4">Pestilence</span> <img src="../img/blood.png" /> | <span class="style4">Heart Strike</span> <img src="../img/blood.png" /> | <span class="style6">Death Strike</span> 

<img src="../img/finisher.png" /> | <span class="style6">Death Coil</span> <img src="../img/finisher.png" alt="unholy" /></p>

<p>Or in longer battles:</p>

<p><span class="style7"><span class="style6">Death Coil</span> <img src="../img/finisher.png" alt="unholy" /> Icy Touch</span> <img src="../img/frost.png" /> | <span class="style2">Plague Strike</span> <img src="../img/unholy.png" /> | <span class="style16">Pestilence</span> <img src="../img/blood.png" /> | <span class="style16">Heart Strike</span> <img src="../img/blood.png" /> | <span class="style6">Death Strike</span> <img src="../img/finisher.png" /> | <span class="style6">Death Coil</span> <img src="../img/finisher.png" alt="unholy" /> | <span class="style6">Death Strike</span> <img src="../img/finisher.png" /> | <span class="style6">Death Coil</span> <img src="../img/finisher.png" alt="unholy" /></p>

<h3>Recommened Gear</h3>
<p>The Death Knight starter will provide you with a full set of blues to get you started, but once you leave Ebon Hold and venture out into the other lands you may want to upgrade your gear. If you're looking for items on the Auction House, generally the stats you want to focus on are Strength and Stamina. A good third stat focus is Critical Hit Chance.
<h3>Talent Trees</h3>
<p>Death Knight talents are split into 3 categories, each of which are fully capable of supporting either a tanking or dps role:</p>
<ul class="ttblood">
<li><strong>Blood</strong>: This tree primarily amplifies the Death Knight's melee spells, weapons, and abilities, and has a prominent health-regeneration theme.</li>
</ul>

<ul class="ttfrost">
<li><strong>Frost</strong>: This tree has many control elements, with a strong critical strike/bonus damage theme, as well as several talents that improve physical damage mitigation.</li>

</ul>

<ul class="ttunholy">
<li><strong>Unholy</strong>: This tree has a heavy focus on diseases and related abilities, as well as improving summoned minions. Also has AoE, spell damage shielding, and mobility-improvement sub-themes.</li>
</ul>

<p><span class="style23">Talent Build</span><br />
  This is the official build we use when creating the guides and it is our recommended solo leveling talent build.</p>
<p><strong>Build for Patch: </strong>3.1.0<strong><br />
  Talent Specialization: </strong>Blood ( 54 / 7/ 10 )<strong><br />
      Last Updated On: </strong>April 21st, 2009<br />
</p>
<div class="center">
<img src="../img/deathknightbuild.png" alt="dkbuild" /></div>

<p style="margin-left: 25px; margin-top: 10px; font-size: 1.3em; text-decoration: underline;"><strong>Blood (54 points)</strong></p>
<ul class="talents">
<li> <input type="checkbox" name="checkbox" value="checkbox"> 
  <strong>Level 10</strong>: <span class="style6">Blade Barrier</span> (1/5)</li>
<li>
  <input type="checkbox" name="checkbox2" value="checkbox" />
  <strong>Level 11</strong>: <span class="style6">Blade Barrier</span> (2/5)</li>
<li>
  <input type="checkbox" name="checkbox3" value="checkbox" />
  <strong>Level 12</strong>:<span class="style6"> Blade Barrier</span> (3/5)</li>
<li>
  <input type="checkbox" name="checkbox4" value="checkbox" />
  <strong>Level 13</strong>:<span class="style6"> Blade Barrier</span> (4/5)</li>
<li>
  <input type="checkbox" name="checkbox5" value="checkbox" />
  <strong>Level 14</strong>: <span class="style6">Blade Barrier</span> (5/5)</li>
<li>
  <input type="checkbox" name="checkbox6" value="checkbox" />
  <strong>Level 15</strong>:<span class="style7"> Bladed Armor</span> (1/5)</li>
<li>
  <input type="checkbox" name="checkbox6" value="checkbox" />
  <strong>Level 16</strong>:<span class="style7"> Bladed Armor</span> (2/5)</li>
<li>
  <input type="checkbox" name="checkbox7" value="checkbox" />
  <strong>Level 17</strong>:<span class="style7"> Bladed Armor</span> (3/5)</li>
<li>
  <input type="checkbox" name="checkbox8" value="checkbox" />
  <strong>Level 18</strong>: <span class="style7">Bladed Armor</span> (4/5)</li>
<li>
  <input type="checkbox" name="checkbox9" value="checkbox" />
  <strong>Level 19</strong>: <span class="style7">Bladed Armor</span> (5/5)</li>
<li></li>
<li>
  <input type="checkbox" name="checkbox10" value="checkbox" />
  <strong>Level 20</strong>: <span class="style6">Two-Handed Weapon Specialization </span> (1/2)</li>
<li>
  <input type="checkbox" name="checkbox11" value="checkbox" />
  <strong>Level 21</strong>:<span class="style6"> Two-Handed Weapon Specialization </span> (2/2)</li>
<li>
  <input type="checkbox" name="checkbox12" value="checkbox" />
  <strong>Level 22</strong>: <span class="style7">Rune Tap </span>(1/1)</li>
<li>
  <input type="checkbox" name="checkbox13" value="checkbox" />
  <strong>Level 23</strong>: <span class="style7">Dark Conviction</span> (1/5)</li>
<li>
  <input type="checkbox" name="checkbox14" value="checkbox" />
  <strong>Level 24</strong>: <span class="style7">Dark Conviction</span> (2/5)</li>
<li>
  <input type="checkbox" name="checkbox15" value="checkbox" />
  <strong>Level 25</strong>: <span class="style7">Dark Conviction</span> (3/5)</li>
</ul>

<ul class="talents">
  <li>
    <input type="checkbox" name="checkbox16" value="checkbox" />
    <strong>Level 26</strong>:<span class="style7"> Dark Conviction</span> (4/5)</li>
  <li>
    <input type="checkbox" name="checkbox17" value="checkbox" />
    <strong>Level 27</strong>:<span class="style7"> Dark Conviction</span> (5/5)</li>
  <li>
    <input type="checkbox" name="checkbox18" value="checkbox" />
    <strong>Level 28</strong>: <span class="style6">Death Rune Mastery</span> (1/3)</li>
  <li>
    <input type="checkbox" name="checkbox19" value="checkbox" />
    <strong>Level 29</strong>:<span class="style6"> Death Rune Mastery</span> (2/3)</li>
  <li>
    <input type="checkbox" name="checkbox20" value="checkbox" />
    <strong>Level 30</strong>:<span class="style6">Death Rune Mastery</span> (3/3)</li>
  <li>
    <input type="checkbox" name="checkbox21" value="checkbox" />
    <strong>Level 31</strong>:<span class="style7"> Bloody Strikes</span> (1/3)</li>
  <li>
    <input type="checkbox" name="checkbox22" value="checkbox" />
    <strong>Level 32</strong>:<span class="style7"> Bloody Strikes</span> (2/3)</li>
  <li>
    <input type="checkbox" name="checkbox23" value="checkbox" />
    <strong>Level 33</strong>: <span class="style7">Bloody Strikes</span> (3/3)</li>
  <li></li>
  <li>
    <input type="checkbox" name="checkbox25" value="checkbox" />
    <strong>Level 34</strong>:<span class="style6"> Veteran of the Third War</span> (1/3)</li>
  <li>
    <input type="checkbox" name="checkbox26" value="checkbox" />
    <strong>Level 35</strong>:<span class="style6"> Veteran of the Third War</span> (2/3)</li>
  <li>
    <input type="checkbox" name="checkbox27" value="checkbox" />
    <strong>Level 36</strong>:<span class="style6"> Veteran of the Third War</span> (3/3)</li>
  <li>
    <input type="checkbox" name="checkbox28" value="checkbox" />
    <strong>Level 37</strong>:<span class="style7"> Mark of Blood</span> (1/1)</li>
  <li>
    <input type="checkbox" name="checkbox29" value="checkbox" />
    <strong>Level 38</strong>:<span class="style6"> Bloody Vengeance</span> (1/3)</li>
  <li>
    <input type="checkbox" name="checkbox30" value="checkbox" />
    <strong>Level 39</strong>:<span class="style6"> Bloody Vengeance</span> (2/3)</li>
  <li>
    <input type="checkbox" name="checkbox31" value="checkbox" />
    <strong>Level 40</strong>:<span class="style6"> Bloody Vengeance</span> (3/3)</li>
  <li>
    <input type="checkbox" name="checkbox32" value="checkbox" />
    <strong>Level 41</strong>:<span class="style7"> Abomination's Might </span>(1/2)</li>
  <li>
    <input type="checkbox" name="checkbox33" value="checkbox" />
    <strong>Level 42</strong>:<span class="style7"> Abomination's Might </span>(2/2)</li>
  <li>
    <input type="checkbox" name="checkbox34" value="checkbox" />
    <strong>Level 43</strong>:<span class="style6"> Bloodworms</span> (1/3)</li>
  <li>
    <input type="checkbox" name="checkbox35" value="checkbox" />
    <strong>Level 44</strong>:<span class="style6"> Bloodworms</span> (2/3)</li>
  <li>
    <input type="checkbox" name="checkbox36" value="checkbox" />
    <strong>Level 45</strong>:<span class="style6"> Bloodworms</span> (3/3)</li>
  <li>
    <input type="checkbox" name="checkbox37" value="checkbox" />
    <strong>Level 46</strong>:<span class="style7"> Improved Death Strike</span> (1/2)</li>
  <li>
    <input type="checkbox" name="checkbox38" value="checkbox" />
    <strong>Level 47</strong>:<span class="style7"> Improved Death Strike</span> (2/2)</li>
  <li>
    <input type="checkbox" name="checkbox39" value="checkbox" />
    <strong>Level 48</strong>: <span class="style6">Sudden Doom</span> (1/3)</li>
  <li>
    <input type="checkbox" name="checkbox40" value="checkbox" />
    <strong>Level 49</strong>:<span class="style6"> Sudden Doom</span> (2/3)</li>
  <li></li>
  <li>
    <input type="checkbox" name="checkbox41" value="checkbox" />
    <strong>Level 50</strong>:<span class="style6"> Sudden Doom</span> (3/3)</li>
  <li>
    <input type="checkbox" name="checkbox42" value="checkbox" />
    <strong>Level 51</strong>:<span class="style7"> Vampiric Blood </span>(1/1)</li>
  <li>
    <input type="checkbox" name="checkbox43" value="checkbox" />
    <strong>Level 52</strong>:<span class="style6"> Will of the Necropolis</span> (1/3)</li>
  <li></li>
  <li>
    <input type="checkbox" name="checkbox44" value="checkbox" />
    <strong>Level 53</strong>: <span class="style6">Will of the Necropolis</span> (2/3)</li>
  <li>
    <input type="checkbox" name="checkbox45" value="checkbox" />
    <strong>Level 54</strong>:<span class="style6"> Will of the Necropolis</span> (3/3)</li>
  <li>
    <input type="checkbox" name="checkbox46" value="checkbox" />
    <strong>Level 55</strong>: <span class="style7">Heart Strike </span>(1/1)</li>
  <li>
    <input type="checkbox" name="checkbox47" value="checkbox" />
    <strong>Level 56</strong>: <span class="style6">Might of Mograine </span>(1/3)</li>
  <li>
    <input type="checkbox" name="checkbox48" value="checkbox" />
    <strong>Level 57</strong>:<span class="style6"> Might of Mograine </span>(2/3)</li>
  <li>
    <input type="checkbox" name="checkbox49" value="checkbox" />
    <strong>Level 58</strong>:<span class="style6"> Might of Mograine </span>(3/3)</li>
  <li>
    <input type="checkbox" name="checkbox50" value="checkbox" />
    <strong>Level 59</strong>: <span class="style7">Blood Gorged</span> (1/5)</li>
  <li>
    <input type="checkbox" name="checkbox51" value="checkbox" />
    <strong>Level 60</strong>: <span class="style7">Blood Gorged</span> (2/5)</li>
  <li>
    <input type="checkbox" name="checkbox52" value="checkbox" />
    <strong>Level 61</strong>: <span class="style7">Blood Gorged</span> (3/5)</li>
  <li>
    <input type="checkbox" name="checkbox53" value="checkbox" />
    <strong>Level 62</strong>:<span class="style7"> Blood Gorged</span> (4/5)</li>
  <li>
    <input type="checkbox" name="checkbox24" value="checkbox" />
    <strong>Level 63</strong>:<span class="style7"> Blood Gorged</span> (5/5)</li>
</ul>
  
  <p style="margin-left: 25px; margin-top: 10px; font-size: 1.3em; text-decoration: underline;"><strong>Unholy (10 points)</strong></p>
<ul class="talents"><li>
  <input type="checkbox" name="checkbox54" value="checkbox" />
  <strong>Level 64</strong>: <span class="style6">Anticipation</span> (1/5)</li>
<li>
  <input type="checkbox" name="checkbox55" value="checkbox" />
  <strong>Level 65</strong>:<span class="style6"> Anticipation</span> (2/5)</li>
<li></li>
<li>
  <input type="checkbox" name="checkbox3" value="checkbox" />
  <strong>Level 66</strong>:<span class="style6"> Anticipation</span> (3/5)</li>
<li>
  <input type="checkbox" name="checkbox56" value="checkbox" />
  <strong>Level 67</strong>:<span class="style6"> Anticipation</span> (4/5)</li>
<li>
  <input type="checkbox" name="checkbox57" value="checkbox" />
  <strong>Level 68</strong>: <span class="style6">Anticipation</span> (5/5)</li>
<li>
  <input type="checkbox" name="checkbox58" value="checkbox" />
  <strong>Level 69</strong>: <span class="style7">Epidemic</span> (1/2)</li>
<li>
  <input type="checkbox" name="checkbox59" value="checkbox" />
  <strong>Level 70</strong>: <span class="style7">Epidemic</span> (2/2)</li>
<li>
  <input type="checkbox" name="checkbox64" value="checkbox" />
  <strong>Level 71</strong>: <span class="style6">Morbidity</span> (1/3)</li>
<li>
  <input type="checkbox" name="checkbox64" value="checkbox" />
  <strong>Level 72</strong>:<span class="style6"> Morbidity</span> (2/3)</li>
<li></li>
<li>
  <input type="checkbox" name="checkbox64" value="checkbox" />
  <strong>Level 73</strong>:<span class="style6"> Morbidity</span> (3/3)</li>
<li></li>
</ul>
<p style="margin-left: 25px; margin-top: 10px; font-size: 1.3em; text-decoration: underline;"><strong>Frost (7 points)</strong></p>
<ul class="talents"><li></li>
  <li>
    <input type="checkbox" name="checkbox60" value="checkbox" />
    <strong>Level 74</strong>:<span class="style7"> Runic Power Mastery</span> (1/2)</li>
  <li>
    <input type="checkbox" name="checkbox60" value="checkbox" />
    <strong>Level 75</strong>: <span class="style7">Runic Power Mastery</span> (2/2)</li>
  <li>
    <input type="checkbox" name="checkbox60" value="checkbox" />
    <strong>Level 76</strong>: <span class="style6">Toughness</span> (1/5)</li>
  <li>
    <input type="checkbox" name="checkbox60" value="checkbox" />
    <strong>Level 77</strong>: <span class="style6">Toughness</span> (2/5)</li>
  <li>
    <input type="checkbox" name="checkbox61" value="checkbox" />
    <strong>Level 78</strong>:<span class="style6"> Toughness</span> (3/5)</li>
  <li>
    <input type="checkbox" name="checkbox62" value="checkbox" />
    <strong>Level 79</strong>:<span class="style6"> Toughness</span> (4/5)</li>
  <li>
    <input type="checkbox" name="checkbox63" value="checkbox" />
    <strong>Level 80</strong>:<span class="style6"> Toughness</span> (5/5)</li>
  </ul>
<p>&nbsp;</p>
<ul class="talents">
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  <li></li>
  <li><span class="style8">Recommended Glyphs:</span><br />
  </li>
  <li><img src="../img/deathknightglyphs.png" alt="deathknightglyphs" width="314" height="176" /></li>
</ul>
<p><br />
</p>
<h3>Useful Macros</h3>
<p><strong>Ejection</strong></p>
<textarea readonly="readonly" wrap="soft" cols="100" rows="3">
#showtooltip Chains of Ice
/cast Chains of Ice
/cast Death Grip</textarea>

<p>Try to press it twice in a row really quickly. It will make the target fly up into the air at a very slow rate (depending on movement speed of the mob), and eventually fall down at a very slow rate. The target can be attacked while in the air, and it serves as a great crowd control, and it only uses one Frost rune. It is more effective the further away you are from your target. Can be used constantly (or near constant) with the Unholy Command talent. Can be used on most mobs. </p>

<p><strong>Runner Stopper</strong></p>
<textarea readonly="readonly" wrap="soft" cols="100" rows="3">
#showtooltip Death Grip
/cast Death Grip
/cast Chains of Ice</textarea>

<p>Casts Death Grip. If Death Grip is on cooldown, Chains of Ice is casted instead. This allows for you to either pull, or stop an enemy from running away with the use of one button. </p>



</div>
</div>
<div id="footer"><p>Copyright © 2008 Zygor Guides, LLC. All Rights Reserved.</p></div>
</div>
</body>
</html>