<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--
##  Zygor Guides | version 1.0 | "PEACH"
##  [ www.zygorguides.com ] [ www.tikitula.com ]
##
##  All contents within are Copyright © 2008, Zygor Guides LLC & The Tiki Tula.
##  All Rights Reserved ® 
-->
<head>
<title>Zygor Guides</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="The #1 best-selling in-game World of Warcraft leveling guides." />
<meta name="keywords" content="world of warcraft guide, world of warcraft leveling, wow leveling guide, alliance leveling guide, horde leveling guide, 1-80 leveling guide, in game leveling guides" />
<meta name="language" content="en-us, english" />
<meta name="classification" content="Blog" />
<meta name="author" content="Andrew Sturgeon" />
<meta name="copyright" content="Zygor Guides LLC" />
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="alternate" type="application/rss+xml" title="The Zygor Guides News Feed" href="http://feeds.feedburner.com/zygorguides" />
<style type='text/css' media='screen'>
<!--
@import url(http://www.zygorguides.com/css/peach.css);

.radio {
display: inline;
}

-->
</style>
<script type="text/javascript" src="../js/flashembed.js"></script>
<script type="text/javascript" src="../js/dropdown.js"></script>
<script language="JavaScript" type="text/javascript">
<!-- Yahoo! Inc.
window.ysm_customData = new Object();
window.ysm_customData.conversion = "transId=,currency=,amount=";
var ysm_accountid  = "1EVG63VVFKPPRLFP421VBP34HTG";
document.write("<SCR" + "IPT language='JavaScript' type='text/javascript' " 
+ "SRC=//" + "srv1.wa.marketingsolutions.yahoo.com" + "/script/ScriptServlet" + "?aid=" + ysm_accountid 
+ "></SCR" + "IPT>");
// -->
</script>
</head>
<body>
<div id="container">
<div id="header"></div>
<div id="navigation">
<ul>
<li><a href="http://www.zygorguides.com" onclick="" onmouseover="dropdownmenu(this, event, menu1, '150px')" onmouseout="delayhidemenu()">Home</a></li>
<li><a href="../news/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu2, '150px')" onmouseout="delayhidemenu()">News</a></li>
<li><a href="../about/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu3, '150px')" onmouseout="delayhidemenu()">About</a></li>
<li><a href="../guides/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu4, '150px')" onmouseout="delayhidemenu()">Guides</a></li>
<li><a href="../freebies/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu5, '150px')" onmouseout="delayhidemenu()">Freebies</a></li>
<li><a href="member.php" onclick="" onmouseover="dropdownmenu(this, event, menu6, '150px')" onmouseout="delayhidemenu()">Members Area</a></li>
<li><a href="../forum/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu7, '150px')" onmouseout="delayhidemenu()">Forum</a></li>
<li><a href="../faq/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu8, '150px')" onmouseout="delayhidemenu()">FAQ</a></li>
<li><a href="../contact/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu9, '150px')" onmouseout="delayhidemenu()">Contact</a></li>
</ul>
</div>
<div id="content">
<div id="main">
<div class="centered">
<div class="bigtext">Members Area</div><div id="login">
<form name="login" method="post" action="/amember/member.php">
<label for="username"><img src="http://www.zygorguides.com/img/username.png" /></img></label>
<input type="text" name="amember_login" size="20" value="" />
<label for="password"><img src="http://www.zygorguides.com/img/password.png" /></img></label>
<input type="password" name="amember_pass" size="20" />
<input type="hidden" name="login_attempt_id" value="1256824894" />
<br />
<div class="buttonarea">
<input type="submit" value="&nbsp;&nbsp;&nbsp;Login&nbsp;&nbsp;&nbsp;" />
</form></div>
</div>
<br />
<div class="center"><p>Not registered yet? <a href="http://www.zygorguides.com/amember/signup.php">Signup here</a></p></div>
<br />

<div class="center"><h3>Lost password?</h3></div><br />
<form name="sendpass" method="post" action="http://www.zygorguides.com/amember/sendpass.php">
<label for="lostemail"><em>Enter your <b>E-Mail Address</b> or <b>Username</b></em></label>
<input type="text" name="login" size="20" />
<div class="buttonarea">
<input type="submit" value="Get Password" /></div>
</form>
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br />


<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>



<script type="text/javascript">
    var pageTracker = _gat._getTracker("UA-3226305-1");
    pageTracker._trackPageview();
</script>
</div>

</div>
</div>
<div id="sidebar">
<div class="feedbox">
<h2>Subscribe:</h2>
<form method="post" action="http://www.aweber.com/scripts/addlead.pl">
<input type="hidden" name="meta_web_form_id" value="1486465894">
<input type="hidden" name="meta_split_id" value="">
<input type="hidden" name="unit" value="zygorguides">
<input type="hidden" name="redirect" value="http://www.aweber.com/form/thankyou_vo.html" id="redirect_56c3aaf87f8c201c3fd33ea0bde91a78">
<input type="hidden" name="meta_redirect_onlist" value="">
<input type="hidden" name="meta_adtracking" value="">
<input type="hidden" name="meta_message" value="1">
<input type="hidden" name="meta_required" value="from">
<input type="hidden" name="meta_forward_vars" value="0">
<label><em>We respect your privacy</em></label>
<input type="text" value="Enter Your Email" onclick="this.value='';" onfocus="this.select()" onblur="this.value=!this.value?'Enter Email Address':this.value;" name="from" size="20">
<div class="buttonarea">
<input type="submit" name="submit" value="Sign Up">
</div>
</form>
<div class="center">
<p>Sign up to our newsletter for free guides, tips and important news regarding our products</p>
</div>
</div>

<div class="sidebox">
<h2>Testimonials:</h2>
<blockquote>
<p>I want to thank you for such a great  alliance leveling guide. I was new to WOW in December and started leveling a character using your alliance leveling guide starting in Feb. I have ran few instances and done most of the quests solo with a bit of help from my son�s Level 70 here and there. I took my time and tried to learn the game. As of this AM, your alliance leveling guide has brought me to level 60.  It has grown to be something I can trust will not waste my time if I stay on course.<br /> - Glyn </p>
</blockquote>
<p class="textright"><a href="../testimonials/index.php">Read More �</a></p>
</div>
</div>
<div id="footer"><p><a href="http://www.zygorguides.com">Home</a> | <a href="../news/index.php">News</a> | <a href="../about/index.php">About</a> | <a href="../guides/index.php">Guides</a> | <a href="../freebies/index.php">Freebies</a> | <a href="../amember/member.php">Members Area</a> | <a href="../forum/index.php">Forum</a> | <a href=".../faq/index.php">FAQ</a> | <a href="../contact/index.php">Contact</a> | <a href="../affiliates/index.php">Affiliates</a></p></div>
</div>
</body>