<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"></html>
<!--
##  Zygor Guides | version 1.0 | "PEACH"
##  [ www.zygorguides.com ] [ www.tikitula.com ]
##
##  All contents within are Copyright © 2008, Zygor Guides LLC & The Tiki Tula.
##  All Rights Reserved ® 
-->
<head>
<title>Zygor Guides</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="The #1 best-selling in-game World of Warcraft leveling guides." />
<meta name="keywords" content="world of warcraft guide, world of warcraft leveling, wow leveling guide, alliance leveling guide, horde leveling guide, 1-80 leveling guide, in game leveling guides" />
<meta name="language" content="en-us, english" />
<meta name="classification" content="Blog" />
<meta name="author" content="Andrew Sturgeon" />
<meta name="copyright" content="Zygor Guides LLC" />
<link rel="alternate" type="application/rss+xml" title="The Zygor Guides News Feed" href="http://feeds.feedburner.com/zygorguides" />
<link rel="alternate" type="application/rss+xml" href="http://www.example.com/forum/external.php?type=rss2" />
<link rel="shortcut icon" href="http://zygorguides.com/favicon.ico" />
<style type='text/css' media='screen'>
<!--
@import url(../css/peach.css);
-->
</style>
<script type="text/javascript" src="../js/flashembed.js"></script>
<script type="text/javascript" src="../js/dropdown.js"></script>
</head>
<body>
<div id="container">
<div id="header"></div>
<div id="navigation">
<ul>
<li><a href="http://www.zygorguides.com" onclick="" onmouseover="dropdownmenu(this, event, menu1, '150px')" onmouseout="delayhidemenu()">Home</a></li>
<li><a href="index.php" onclick="" onmouseover="dropdownmenu(this, event, menu2, '150px')" onmouseout="delayhidemenu()">News</a></li>
<li><a href="../about/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu3, '150px')" onmouseout="delayhidemenu()">About</a></li>
<li><a href="../guides/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu4, '150px')" onmouseout="delayhidemenu()">Guides</a></li>
<li><a href="../freetrial/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu5, '150px')" onmouseout="delayhidemenu()">Free Trial</a></li>
<li><a href="../amember/member.php" onclick="" onmouseover="dropdownmenu(this, event, menu6, '150px')" onmouseout="delayhidemenu()">Members Area</a></li>
<li><a href="../forum/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu7, '150px')" onmouseout="delayhidemenu()">Forum</a></li>
<li><a href="../faq/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu8, '150px')" onmouseout="delayhidemenu()">FAQ</a></li>
<li><a href="../contact/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu9, '150px')" onmouseout="delayhidemenu()">Contact</a></li>
</ul>
</div>
<div id="content">
<div id="flashbox">
<div id="flashcontent">
You must download <a href="http://www.adobe.com/go/getflashplayer" onclick="window.open(this.href,'_blank');return false;">Adobe Flash Player</a> to see this section.</div>
<div id="player">
<script type="text/javascript">
var so = new SWFObject('../flash/rotator/imagerotator.swf','mpl','500','250','8');
so.addParam('allowscriptaccess','always');
so.addParam('allowfullscreen','true');
so.addParam("wmode", "transparent");
so.addVariable('height','250');
so.addVariable('width','500');
so.addVariable('file','../flash/rotator/imagelist2.xml');
so.addVariable('transition','fade');
so.addVariable('linkfromdisplay', 'true');
so.addVariable('shuffle', 'false');
so.addVariable('showicons', 'false');
so.write('flashcontent');
</script></div>
</div>
<div id="main">
<h1><a href="/news/index.php?subaction=showfull&amp;id=1256146515&amp;archive=&amp;start_from=&amp;ucat=&amp;">Zygor Guides 2.0</a> <a href="http://feeds.feedburner.com/zygorguides"><img src="http://www.zygorguides.com/img/rss.gif" class="noborder" /></img></a></h1>
<span class="author_and_date"><em>by</em> <span class="author"><a href="mailto:haell@zygorguides.com">Haell</a></span>
<em>on</em> October 21st, 2009 | <a href="/news/index.php?subaction=showcomments&amp;id=1256146515&amp;archive=&amp;start_from=&amp;ucat=&amp;">0 Comments</a></span>
 <p>If you tried to purchase Version 2.0 yesterday, you may have noticed
 our server was completely crippled with the huge influx of traffic
 we received, along with the lengthy downtime our site experienced
 last night.</p>
 
  <p>Last night, we moved to a much more powerful server that can easily
 handle the enormous amount of traffic we have been receiving, so you
 should now be able to purchase your copy of the Version 2.0 guides.
 We sincerely apologize for the inconvenience this may have caused you
 and appreciate your patience and support. </p>
 
  <p>As a token of our gratitude, we have increased the number of buyers 
 who will receive the limited bonuses we are giving away from 1,000 
 to 3,000.</p>
 
  <p>If you want any chance of getting your hands on the bonuses we're 
 giving away for the first select few buyers, you need to buy NOW. 
 So many people want these Version 2.0 leveling guides, there is 
 absolutely no way these bonuses will last very long at all.</p>
 
  <p>Bonuses:
 --------------
 Auctioneer Apprasier Guide
 Food & Stats Guide
 Zygor's Talent Advisor: Dual Spec In-Game Step-By-Step Talent Builds</p>
 
  <p>If you want these bonuses, don't waste any more time, head over to 
 our website and purchase your copy of our Version 2.0 leveling guides 
 and start power leveling your characters RIGHT NOW.</p><h1><a href="/news/index.php?subaction=showfull&amp;id=1240421039&amp;archive=1255353625&amp;start_from=&amp;ucat=&amp;">Talent Builds Updated</a> <a href="http://feeds.feedburner.com/zygorguides"><img src="http://www.zygorguides.com/img/rss.gif" class="noborder" /></img></a></h1>
<span class="author_and_date"><em>by</em> <span class="author"><a href="mailto:haell@zygorguides.com">Haell</a></span>
<em>on</em> April 22nd, 2009 | <a href="/news/index.php?subaction=showcomments&amp;id=1240421039&amp;archive=1255353625&amp;start_from=&amp;ucat=&amp;">4 Comments</a></span>
<p>After much demand we have updated the talent builds section to work with patch 3.1.0. Remember, these builds are the official builds we use when making the guide and are intended to be the best for solo leveling. They aren't necessarily geared towards PVP, raiding or instancing. A few classes now have multiple builds provided so that you can choose the route you would like to take. For Hunters, we now recommend what pet to use and provide a recommended pet talent build as well. A list of major and minor glyph recommendations are also included now. </p>

<p>If any changes are made they will be posted at the top in the new timestamp we include which will give you an indication of when we last updated the builds. If you notice any problems with the builds or typos please report them using our Contact page.</p><!-- News Powered by CuteNews: http://cutephp.com/ --></div>
</div>
<div id="sidebar">
<div class="feedbox">
<h2>Subscribe:</h2>
<form method="post" action="http://www.aweber.com/scripts/addlead.pl">
<input type="hidden" name="meta_web_form_id" value="1486465894">
<input type="hidden" name="meta_split_id" value="">
<input type="hidden" name="unit" value="zygorguides">
<input type="hidden" name="redirect" value="http://www.aweber.com/form/thankyou_vo.html" id="redirect_56c3aaf87f8c201c3fd33ea0bde91a78">
<input type="hidden" name="meta_redirect_onlist" value="">
<input type="hidden" name="meta_adtracking" value="">
<input type="hidden" name="meta_message" value="1">
<input type="hidden" name="meta_required" value="from">
<input type="hidden" name="meta_forward_vars" value="0">
<label><em>We respect your privacy</em></label>
<input type="text" value="Enter Your Email" onclick="this.value='';" onfocus="this.select()" onblur="this.value=!this.value?'Enter Email Address':this.value;" name="from" size="20">
<div class="buttonarea">
<input type="submit" name="submit" value="Sign Up">
</div>
</form>
<div class="center">
<p>Sign up to our newsletter for free guides, tips and important news regarding our products</p>
</div>
</div>


<div class="sidebox">
<script src="http://widgets.twimg.com/j/2/widget.js"></script>
<script>
new TWTR.Widget({
  version: 2,
  type: 'profile',
  rpp: 4,
  interval: 6000,
  width: 220,
  height: 300,
  theme: {
    shell: {
      background: '#4589ab',
      color: '#252525'
    },
    tweets: {
      background: '#ffffff',
      color: '#252525',
      links: '#213c57'
    }
  },
  features: {
    scrollbar: true,
    loop: false,
    live: false,
    hashtags: true,
    timestamp: true,
    avatars: false,
    behavior: 'all'
  }
}).render().setUser('zygorguides').start();
</script>
</div>

<div class="sidebox">
<h2>Recent Forum Posts:</h2>
<div id="topics">
<div class="darkbox">
<div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3315&goto=newpost'>Blood Elf Paladin Quests</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 01:35 PM </span></p></div><div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3313&goto=newpost'>Suggestion</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 12:03 PM </span></p></div><div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3312&goto=newpost'>Blood Elf Hunter</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 10:23 AM </span></p></div><div class='darkbox'><p><span class='topicheader'><a href='http://www.zygorguides.com/forum/showthread.php?t=3310&goto=newpost'>Guides resetting each time I start WOW</a></span></p>
		 <p><span class='topicdetails'>Posted on October 29th, 2009 at 06:26 AM </span></p></div></div></div>
<img src="../img/gnomeposts.png" /></img>
</div>



</div><div id="footer"><p><a href="http://www.zygorguides.com">Home</a> | <a href="http://www.zygorguides.com/news/index.php">News</a> | <a href="http://www.zygorguides.com/about/index.php">About</a> | <a href="http://www.zygorguides.com/guides/index.php">Guides</a> | <a href="http://www.zygorguides.com/freebies/index.php">Freebies</a> | <a href="http://www.zygorguides.com/amember/member.php">Members Area</a> | <a href="http://www.zygorguides.com/forum/index.php">Forum</a> | <a href="http://www.zygorguides.com/faq/index.php">FAQ</a> | <a href="http://www.zygorguides.com/contact/index.php">Contact</a> | <a href="http://www.zygorguides.com/affiliates/index.php">Affiliates</a></p></div>
</div>
</body>