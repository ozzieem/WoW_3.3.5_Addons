<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en">
<head>
	<!-- no cache headers -->
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Expires" content="-1" />
	<meta http-equiv="Cache-Control" content="no-cache" />
	<!-- end no cache headers -->
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<meta name="generator" content="vBulletin 3.8.4" />

<meta name="keywords" content="wow leveling guide, horde leveling guide, alliance leveling guide, world of warcraft, wow, alliance, horde, wotlk guide" />
<meta name="description" content="The official community forum of Zygor Guides." />


<!-- CSS Stylesheet -->
<style type="text/css" id="vbulletin_css">
/**
* vBulletin 3.8.4 CSS
* Style: 'Default Style'; Style ID: 1
*/
body
{
	background: #E1E1E2;
	color: #000000;
	margin: 0px 0px 0px 0px;
	padding: 0px;
	background: #252525 url(http://www.zygorguides.com/img/back.gif) top left repeat;
	font-size: 0.8em;
	
}
a:link, body_alink
{
	color: #213c57;
}
a:visited, body_avisited
{
	color: #213c57;
}
a:hover, a:active, body_ahover
{
	color: #213c57;
	text-decoration: underline;
}
.page
{
	background: #bdd7e5;
	color: #000000;
}
td, th, p, li
{
	font-family: verdana;
	line-height: 1.5;
}
.tborder
{
	background: #000000;
	color: #000000;
	border: 1px solid #000000;
}
.tcat
{
	background: #3b7197;
	color: #ffffff;
	font-family: arial, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	font-weight: bold;
	font-size: 1.0em;
}
.tcat a:link, .tcat_alink
{
	color: #ffffff;
	text-decoration: none;
}
.tcat a:visited, .tcat_avisited
{
	color: #ffffff;
	text-decoration: none;
}
.tcat a:hover, .tcat a:active, .tcat_ahover
{
	color: #ffffff;
	text-decoration: underline;
}
.thead
{
	background: #375b89;
	color: #FFFFFF;
	font: bold 11px tahoma, verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.thead a:link, .thead_alink
{
	color: #FFFFFF;
}
.thead a:visited, .thead_avisited
{
	color: #FFFFFF;
}
.thead a:hover, .thead a:active, .thead_ahover
{
	color: #ffffff;
}
.tfoot
{
	background: #375b89;
	color: #ffffff;
}
.tfoot a:link, .tfoot_alink
{
	color: #E0E0F6;
}
.tfoot a:visited, .tfoot_avisited
{
	color: #E0E0F6;
}
.tfoot a:hover, .tfoot a:active, .tfoot_ahover
{
	color: #ffffff;
}
.alt1, .alt1Active
{
	background: #ffffff;
	color: #000000;
}
.alt2, .alt2Active
{
	background: #edf3f6;
	color: #000000;
}
.inlinemod
{
	background: #FFFFCC;
	color: #000000;
}
.wysiwyg
{
	background: #ffffff;
	color: #000000;
	font: 10pt verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	margin: 5px 10px 10px 10px;
	padding: 0px;
}
.wysiwyg a:link, .wysiwyg_alink
{
	color: #22229C;
}
.wysiwyg a:visited, .wysiwyg_avisited
{
	color: #22229C;
}
.wysiwyg a:hover, .wysiwyg a:active, .wysiwyg_ahover
{
	color: #FF4400;
}
textarea, .bginput
{
	font: 10pt verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.bginput option, .bginput optgroup
{
	font-size: 10pt;
	font-family: verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.button
{
	font: 11px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
select
{
	font: 11px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
option, optgroup
{
	font-size: 11px;
	font-family: verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.smallfont
{
	font: 11px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.time
{
	color: #000000;
}
.navbar
{
	font: 11px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.highlight
{
	color: #FF0000;
	font-weight: bold;
}
.fjsel
{
	background: #3E5C92;
	color: #E0E0F6;
}
.fjdpth0
{
	background: #F7F7F7;
	color: #000000;
}
.panel
{
	background: #E4E7F5 url(images/gradients/gradient_panel.gif) repeat-x top left;
	color: #000000;
	padding: 10px;
	border: 2px outset;
}
.panelsurround
{
	background: #D1D4E0 url(images/gradients/gradient_panelsurround.gif) repeat-x top left;
	color: #000000;
}
legend
{
	color: #22229C;
	font: 11px tahoma, verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
}
.vbmenu_control
{
	background: #252525;
	color: #FFFFFF;
	font-family: arial, verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	font-weight: bold;
	padding: 3px 6px 3px 6px;
	white-space: nowrap;
	font-size: 1.0em;
	
	
}
.vbmenu_control a:link, .vbmenu_control_alink
{
	color: #FFFFFF;
	text-decoration: none;
}
.vbmenu_control a:visited, .vbmenu_control_avisited
{
	color: #FFFFFF;
	text-decoration: none;
}
.vbmenu_control a:hover, .vbmenu_control a:active, .vbmenu_control_ahover
{
	color: #FFFFFF;
	text-decoration: underline;
}
.vbmenu_popup
{
	background: #FFFFFF;
	color: #000000;
	border: 1px solid #0B198C;
	
}
.vbmenu_option
{
	background: #FFFFFF;
	color: #000000;
	font: 11px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	white-space: nowrap;
	cursor: pointer;
}
.vbmenu_option a:link, .vbmenu_option_alink
{
	color: #6f3951;
	text-decoration: none;
}
.vbmenu_option a:visited, .vbmenu_option_avisited
{
	color: #6f3951;
	text-decoration: none;
}
.vbmenu_option a:hover, .vbmenu_option a:active, .vbmenu_option_ahover
{
	color: #FFFFFF;
	text-decoration: none;
}
.vbmenu_hilite
{
	font: 11px verdana, geneva, lucida, 'lucida grande', arial, helvetica, sans-serif;
	white-space: nowrap;
	cursor: pointer;
}
.vbmenu_hilite a:link, .vbmenu_hilite_alink
{
	color: #213c57;
	text-decoration: none;
}
.vbmenu_hilite a:visited, .vbmenu_hilite_avisited
{
	color: #213c57;
	text-decoration: none;
}
.vbmenu_hilite a:hover, .vbmenu_hilite a:active, .vbmenu_hilite_ahover
{
	color: #213c57;
	text-decoration: none;
}
/* ***** styling for 'big' usernames on postbit etc. ***** */
.bigusername { font-size: 14pt; }

/* ***** small padding on 'thead' elements ***** */
td.thead, th.thead, div.thead { padding: 4px; }

/* ***** basic styles for multi-page nav elements */
.pagenav a { text-decoration: none; }
.pagenav td { padding: 2px 4px 2px 4px; }

/* ***** de-emphasized text */
.shade, a.shade:link, a.shade:visited { color: #777777; text-decoration: none; }
a.shade:active, a.shade:hover { color: #FF4400; text-decoration: underline; }
.tcat .shade, .thead .shade, .tfoot .shade { color: #DDDDDD; }

/* ***** define margin and font-size for elements inside panels ***** */
.fieldset { margin-bottom: 6px; }
.fieldset, .fieldset td, .fieldset p, .fieldset li { font-size: 11px; }

.vbmenu_control { background: url(http://www.zygorguides.com/img/nav.png) repeat-x; height: 35px;}
</style>
<link rel="stylesheet" type="text/css" href="clientscript/vbulletin_important.css?v=384" />


<!-- / CSS Stylesheet -->

<script type="text/javascript" src="clientscript/yui/yahoo-dom-event/yahoo-dom-event.js?v=384"></script>
<script type="text/javascript" src="clientscript/yui/connection/connection-min.js?v=384"></script>
<script type="text/javascript">
<!--
var SESSIONURL = "s=8fd35be7eba7aeaf7947bd3c43cc2c2d&";
var SECURITYTOKEN = "guest";
var IMGDIR_MISC = "images/misc";
var vb_disable_ajax = parseInt("0", 10);
// -->
</script>
<script type="text/javascript" src="clientscript/vbulletin_global.js?v=384"></script>



	<link rel="alternate" type="application/rss+xml" title="Zygor Guides Community Forum RSS Feed" href="external.php?type=RSS2" />
	

	<title>Zygor Guides Community Forum - Powered by vBulletin</title>
</head>
<body>
<!-- logo -->
<a name="top"></a>
<table border="0" width="800" cellpadding="0" cellspacing="0" align="center">
<tr>
<td align="center"><a href="index.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;"><img src="http://www.zygorguides.com/img/header.jpg" border="0" alt="Zygor Guides Community Forum" /></a></td>
</tr>
</table>
<!-- /logo -->

<!-- content table -->
<!-- open content container -->

<div align="center">
	<div class="page" style="width:800px; text-align:left">
		<div style="padding:0px 25px 0px 25px" align="left">





<br />

<!-- breadcrumb, login, pm info -->
<table class="tborder" cellpadding="6" cellspacing="1" border="0" width="100%" align="center">
<tr>
	<td class="alt1" width="100%">
		
			<div class="navbar" style="font-size:10pt"><a href="index.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d" accesskey="1"><img class="inlineimg" src="images/misc/navbits_start.gif" alt="" border="0" /></a> <strong>Zygor Guides Community Forum</strong></div>
		
	</td>

	<td class="alt2" nowrap="nowrap" style="padding:0px">
		<!-- login form -->
		<form action="login.php?do=login" method="post" onsubmit="md5hash(vb_login_password, vb_login_md5password, vb_login_md5password_utf, 0)">
		<script type="text/javascript" src="clientscript/vbulletin_md5.js?v=384"></script>
		<table cellpadding="0" cellspacing="3" border="0">
		<tr>
			<td class="smallfont" style="white-space: nowrap;"><label for="navbar_username">User Name</label></td>
			<td><input type="text" class="bginput" style="font-size: 11px" name="vb_login_username" id="navbar_username" size="10" accesskey="u" tabindex="101" value="User Name" onfocus="if (this.value == 'User Name') this.value = '';" /></td>
			<td class="smallfont" nowrap="nowrap"><label for="cb_cookieuser_navbar"><input type="checkbox" name="cookieuser" value="1" tabindex="103" id="cb_cookieuser_navbar" accesskey="c" />Remember Me?</label></td>
		</tr>
		<tr>
			<td class="smallfont"><label for="navbar_password">Password</label></td>
			<td><input type="password" class="bginput" style="font-size: 11px" name="vb_login_password" id="navbar_password" size="10" tabindex="102" /></td>
			<td><input type="submit" class="button" value="Log in" tabindex="104" title="Enter your username and password in the boxes provided to login, or click the 'register' button to create a profile for yourself." accesskey="s" /></td>
		</tr>
		</table>
		<input type="hidden" name="s" value="8fd35be7eba7aeaf7947bd3c43cc2c2d" />
		<input type="hidden" name="securitytoken" value="guest" />
		<input type="hidden" name="do" value="login" />
		<input type="hidden" name="vb_login_md5password" />
		<input type="hidden" name="vb_login_md5password_utf" />
		</form>
		<!-- / login form -->
	</td>

</tr>
</table>
<!-- / breadcrumb, login, pm info -->

<!-- nav buttons bar -->
<div class="tborder" style="padding:1px; border-top-width:0px">
	<table cellpadding="0" cellspacing="0" border="0" width="100%" align="center">
	<tr align="center">
		
		
			<td class="vbmenu_control"><a href="register.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d" rel="nofollow">Register</a></td>
		
		
		<td class="vbmenu_control"><a rel="help" href="faq.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d" accesskey="5">FAQ</a></td>
		
			
				<td class="vbmenu_control"><a href="memberlist.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d">Members List</a></td>
			
			
		
		<td class="vbmenu_control"><a href="calendar.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d">Calendar</a></td>
		
			
				<td class="vbmenu_control"><a href="search.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d" accesskey="4">Search</a></td>
				
				<td class="vbmenu_control"><a href="search.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;do=getdaily" accesskey="2">Today's Posts</a></td>
				
			
			<td class="vbmenu_control"><a href="forumdisplay.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;do=markread" rel="nofollow">Mark Forums Read</a></td>
			
		
		
		
		</tr>
	</table>
</div>
<!-- / nav buttons bar -->

<br />












<!-- guest welcome message -->
<table class="tborder" cellpadding="6" cellspacing="1" border="0" width="100%" align="center">
<tr>
	<td class="tcat">Welcome to the Zygor Guides Community Forum.</td>
</tr>
<tr>
	<td class="alt1">
		If this is your first visit, be sure to check out the <a href="faq.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d"><strong>FAQ</strong></a> by clicking the link above.
You may have to <a href="register.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d" rel="nofollow"><strong>register</strong></a> before you can post: click the register link above to proceed.
To start viewing messages, select the forum that you want to visit from the selection below.
	</td>
</tr>
</table>
<!-- / guest welcome message -->
<br />


<!-- main -->
<table class="tborder" cellpadding="6" cellspacing="1" border="0" width="100%" align="center">
<thead>
	<tr align="center">
	  <td class="thead">&nbsp;</td>
	  <td class="thead" width="100%" align="left">Forum</td>
	  <td class="thead">Last Post</td>
	  <td class="thead">Threads</td>
	  <td class="thead">Posts</td>
	  
	</tr>
</thead>

<tbody>

	<tr>
		<td class="tcat" colspan="5">
			
			<a style="float:right" href="#top" onclick="return toggle_collapse('forumbit_5')"><img id="collapseimg_forumbit_5" src="images/buttons/collapse_tcat.gif" alt="" border="0" /></a>
			
			<a href="forumdisplay.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;f=5">Zygor Guides</a>
			
			
		</td>
	</tr>

</tbody>



<tbody id="collapseobj_forumbit_5" style="">

<tr align="center">
	<td class="alt2"><img src="images/statusicon/forum_old.gif" alt="" border="0" id="forum_statusicon_6" /></td>
	<td class="alt1Active" align="left" id="f6">
		<div>
			<a href="forumdisplay.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;f=6"><strong>Announcements</strong></a>
			<span class="smallfont">(3 Viewing)</span>
		</div>
		<div class="smallfont">This is where the staff will announce new products or changes to the site.</div>
		
		
	</td>
	<td class="alt2">
<div class="smallfont" align="left">
	<div>
		<span style="white-space:nowrap">
		<img class="inlineimg" src="images/icons/icon1.gif" alt="" border="0" />
		
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;goto=newpost&amp;t=3307" style="white-space:nowrap" title="Go to first unread post in thread 'Secret Life of Tweeting Gnomes Exposed - Raw and Uncut'"><strong>Secret Life of Tweeting...</strong></a></span>
	</div>
	<div style="white-space:nowrap">
		by <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;find=lastposter&amp;f=6" rel="nofollow">cabby</a>
	</div>
	<div align="right" style="white-space:nowrap">
		13 Minutes Ago 
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;p=15936#post15936"><img class="inlineimg" src="images/buttons/lastpost.gif" alt="Go to last post" border="0" /></a>
	</div>
</div>
</td>
	<td class="alt1">9</td>
	<td class="alt2">482</td>
	
</tr>
<tr align="center">
	<td class="alt2"><img src="images/statusicon/forum_old.gif" alt="" border="0" id="forum_statusicon_8" /></td>
	<td class="alt1Active" align="left" id="f8">
		<div>
			<a href="forumdisplay.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;f=8"><strong>General Guide Discussion</strong></a>
			<span class="smallfont">(5 Viewing)</span>
		</div>
		<div class="smallfont">Discuss any of our products here.</div>
		
		
	</td>
	<td class="alt2">
<div class="smallfont" align="left">
	<div>
		<span style="white-space:nowrap">
		<img class="inlineimg" src="images/icons/icon1.gif" alt="" border="0" />
		
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;goto=newpost&amp;t=3164" style="white-space:nowrap" title="Go to first unread post in thread 'Official Talent Builds thread!'"><strong>Official Talent Builds thread!</strong></a></span>
	</div>
	<div style="white-space:nowrap">
		by <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;find=lastposter&amp;f=8" rel="nofollow">cabby</a>
	</div>
	<div align="right" style="white-space:nowrap">
		7 Minutes Ago 
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;p=15938#post15938"><img class="inlineimg" src="images/buttons/lastpost.gif" alt="Go to last post" border="0" /></a>
	</div>
</div>
</td>
	<td class="alt1">107</td>
	<td class="alt2">746</td>
	
</tr>
<tr align="center">
	<td class="alt2"><img src="images/statusicon/forum_old.gif" alt="" border="0" id="forum_statusicon_10" /></td>
	<td class="alt1Active" align="left" id="f10">
		<div>
			<a href="forumdisplay.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;f=10"><strong>Alliance Guide</strong></a>
			<span class="smallfont">(1 Viewing)</span>
		</div>
		<div class="smallfont">Discuss topics pertaining to our Alliance Leveling Guide.</div>
		
		
	</td>
	<td class="alt2">
<div class="smallfont" align="left">
	<div>
		<span style="white-space:nowrap">
		<img class="inlineimg" src="images/icons/icon1.gif" alt="" border="0" />
		
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;goto=newpost&amp;t=3298" style="white-space:nowrap" title="Go to first unread post in thread 'Talent guide's points sugestion not accurate'"><strong>Talent guide's points...</strong></a></span>
	</div>
	<div style="white-space:nowrap">
		by <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;find=lastposter&amp;f=10" rel="nofollow">cabby</a>
	</div>
	<div align="right" style="white-space:nowrap">
		25 Minutes Ago 
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;p=15931#post15931"><img class="inlineimg" src="images/buttons/lastpost.gif" alt="Go to last post" border="0" /></a>
	</div>
</div>
</td>
	<td class="alt1">36</td>
	<td class="alt2">204</td>
	
</tr>
<tr align="center">
	<td class="alt2"><img src="images/statusicon/forum_old.gif" alt="" border="0" id="forum_statusicon_11" /></td>
	<td class="alt1Active" align="left" id="f11">
		<div>
			<a href="forumdisplay.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;f=11"><strong>Horde Guide</strong></a>
			<span class="smallfont">(1 Viewing)</span>
		</div>
		<div class="smallfont">Discuss topics pertaining to our Horde Leveling Guide.</div>
		
		
	</td>
	<td class="alt2">
<div class="smallfont" align="left">
	<div>
		<span style="white-space:nowrap">
		<img class="inlineimg" src="images/icons/icon1.gif" alt="" border="0" />
		
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;goto=newpost&amp;t=3315" style="white-space:nowrap" title="Go to first unread post in thread 'Blood Elf Paladin Quests'"><strong>Blood Elf Paladin Quests</strong></a></span>
	</div>
	<div style="white-space:nowrap">
		by <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;find=lastposter&amp;f=11" rel="nofollow">paulrdietz</a>
	</div>
	<div align="right" style="white-space:nowrap">
		4 Minutes Ago 
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;p=15939#post15939"><img class="inlineimg" src="images/buttons/lastpost.gif" alt="Go to last post" border="0" /></a>
	</div>
</div>
</td>
	<td class="alt1">27</td>
	<td class="alt2">145</td>
	
</tr>


</tbody>


<tbody>

	<tr>
		<td class="tcat" colspan="5">
			
			<a style="float:right" href="#top" onclick="return toggle_collapse('forumbit_37')"><img id="collapseimg_forumbit_37" src="images/buttons/collapse_tcat.gif" alt="" border="0" /></a>
			
			<a href="forumdisplay.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;f=37">Off Topic</a>
			
			
		</td>
	</tr>

</tbody>



<tbody id="collapseobj_forumbit_37" style="">

<tr align="center">
	<td class="alt2"><img src="images/statusicon/forum_old.gif" alt="" border="0" id="forum_statusicon_38" /></td>
	<td class="alt1Active" align="left" id="f38">
		<div>
			<a href="forumdisplay.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;f=38"><strong>Off Topic</strong></a>
			<span class="smallfont">(1 Viewing)</span>
		</div>
		<div class="smallfont">Discuss topics not pertaining to Zygor Guides.</div>
		
		
	</td>
	<td class="alt2">
<div class="smallfont" align="left">
	<div>
		<span style="white-space:nowrap">
		<img class="inlineimg" src="images/icons/icon1.gif" alt="" border="0" />
		
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;goto=newpost&amp;t=3272" style="white-space:nowrap" title="Go to first unread post in thread 'Hunter Pets'"><strong>Hunter Pets</strong></a></span>
	</div>
	<div style="white-space:nowrap">
		by <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;find=lastposter&amp;f=38" rel="nofollow">buckynaked</a>
	</div>
	<div align="right" style="white-space:nowrap">
		1 Hour Ago 
		<a href="showthread.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;p=15921#post15921"><img class="inlineimg" src="images/buttons/lastpost.gif" alt="Go to last post" border="0" /></a>
	</div>
</div>
</td>
	<td class="alt1">22</td>
	<td class="alt2">171</td>
	
</tr>


</tbody>


<tbody>
	<tr>
		<td class="tfoot" align="center" colspan="5"><div class="smallfont"><strong>
			<a href="forumdisplay.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;do=markread" rel="nofollow">Mark Forums Read</a>
			&nbsp; &nbsp;
			<a href="showgroups.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d">View Forum Leaders</a>
		</strong></div></td>
	</tr>
</tbody>
</table>
<script type="text/javascript" src="clientscript/vbulletin_read_marker.js?v=384"></script>
<script type="text/javascript">
<!--
vbphrase['doubleclick_forum_markread'] = "Double-click this icon to mark this forum and its contents as read";
init_forum_readmarker_system();
//-->
</script>
<!-- /main -->

<br />

<br />

<!-- what's going on box -->
<table class="tborder" cellpadding="6" cellspacing="1" border="0" width="100%" align="center">
<thead>
	<tr>
		<td class="tcat" colspan="2">What's Going On?</td>
	</tr>
</thead>


<!-- logged-in users -->
<tbody>
	<tr>
		<td class="thead" colspan="2">
			<a style="float:right" href="#top" onclick="return toggle_collapse('forumhome_activeusers')"><img id="collapseimg_forumhome_activeusers" src="images/buttons/collapse_thead.gif" alt="" border="0" /></a>
			<a href="online.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d">Currently Active Users</a>: 25 (12 members and 13 guests)
		</td>
	</tr>
</tbody>
<tbody id="collapseobj_forumhome_activeusers" style="">
	<tr>
		<td class="alt2"><a href="online.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d"><img src="images/misc/whos_online.gif" alt="View Who's Online" border="0" /></a></td>
		<td class="alt1" width="100%">
			<div class="smallfont">
				<div style="white-space: nowrap">Most users ever online was 192, August 4th, 2009 at 07:26 PM.</div>
				<div><a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=17183">Bouvi</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=17444">cabby</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=18168">chills</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=28817">gwom</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=35079">markm</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=31213">paulrdietz</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=10443">scottvin</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=26326"><span style="color: #2e1e3a; font-weight:bold;">silverhawk11</span></a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=34956">sofunktified</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=16769">sonalita</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=3854">TheBissto</a>, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=13083"><span style="color: #2e1e3a; font-weight:bold;">ZG Support</span></a></div>
			</div>
		</td>
	</tr>
</tbody>
<!-- end logged-in users -->


<tbody>
	<tr>
		<td class="thead" colspan="2">
			<a style="float:right" href="#top" onclick="return toggle_collapse('forumhome_stats')"><img id="collapseimg_forumhome_stats" src="images/buttons/collapse_thead.gif" alt="" border="0" /></a>
			Zygor Guides Community Forum Statistics
		</td>
	</tr>
</tbody>
<tbody id="collapseobj_forumhome_stats" style="">
	<tr>
		<td class="alt2"><img src="images/misc/stats.gif" alt="Zygor Guides Community Forum Statistics" border="0" /></td>
		<td class="alt1" width="100%">
		<div class="smallfont">
			<div>
				Threads: 374,
				Posts: 2,395,
				Members: 29,269,
					<span title="Within the Last 30 Days">Active Members: 29,269</span>
				
			</div>
			<div>Welcome to our newest member, <a href="member.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d&amp;u=35445">haare</a></div>
			
		</div>
		</td>
	</tr>
</tbody>





</table>
<br />
<!-- end what's going on box -->

<!-- icons and login code -->
<table cellpadding="0" cellspacing="2" border="0" width="100%">
<tr valign="bottom">
	<td>
		<table cellpadding="2" cellspacing="0" border="0">
		<tr>
			<td><img src="images/statusicon/forum_new.gif" alt="Contains New Posts" border="0" /></td>
			<td class="smallfont">&nbsp; Forum Contains New Posts</td>
		</tr>
		<tr>
			<td><img src="images/statusicon/forum_old.gif" alt="Contains No New Posts" border="0" /></td>
			<td class="smallfont">&nbsp; Forum Contains No New Posts</td>
		</tr>
		
		</table>
	</td>
	
</tr>
</table>
<!-- / icons and login code -->



<br />
<div class="smallfont" align="center">All times are GMT -5. The time now is <span class="time">09:02 AM</span>.</div>
<br />


		</div>
	</div>
</div>

<!-- / close content container -->
<!-- /content area table -->

<form action="index.php" method="get" style="clear:left">

<table cellpadding="6" cellspacing="0" border="0" width="800" class="page" align="center">
<tr>
	
	
	<td class="tfoot" align="right" width="100%">
		<div class="smallfont">
			<strong>
				<a href="http://www.zygorguides.com/contact/index.php?s=8fd35be7eba7aeaf7947bd3c43cc2c2d" rel="nofollow" accesskey="9">Contact Us</a> -
				<a href="http://www.zygorguides.com">Zygor Guides</a> -
				
				
				<a href="archive/index.php">Archive</a> -
				
				
				
				<a href="#top" onclick="self.scrollTo(0, 0); return false;">Top</a>
			</strong>
		</div>
	</td>
</tr>
</table>

<br />

<div align="center">
	<div class="smallfont" align="center">
	<!-- Do not remove this copyright notice -->
	Powered by vBulletin&reg; Version 3.8.4<br />Copyright &copy;2000 - 2009, Jelsoft Enterprises Ltd.
	<!-- Do not remove this copyright notice -->
	</div>

	<div class="smallfont" align="center">
	<!-- Do not remove cronimage or your scheduled tasks will cease to function -->
	
	<!-- Do not remove cronimage or your scheduled tasks will cease to function -->

	Copyright � 2008 Zygor Guides LLC
	</div>
</div>

</form>




<script type="text/javascript">
<!--
	// Main vBulletin Javascript Initialization
	vBulletin_init();
//-->
</script>
</body>
</html>