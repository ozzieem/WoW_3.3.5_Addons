<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--
##  Zygor Guides | version 1.0 | "PEACH"
##  [ www.zygorguides.com ] [ www.tikitula.com ]
##
##  All contents within are Copyright © 2008, Zygor Guides LLC & The Tiki Tula.
##  All Rights Reserved ® 
-->
<head>
<title>Zygor Guides</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="The #1 best-selling in-game World of Warcraft leveling guides." />
<meta name="keywords" content="world of warcraft guide, world of warcraft leveling, wow leveling guide, alliance leveling guide, horde leveling guide, 1-80 leveling guide, in game leveling guides" />
<meta name="language" content="en-us, english" />
<meta name="classification" content="Blog" />
<meta name="author" content="Andrew Sturgeon" />
<meta name="copyright" content="Zygor Guides LLC" />
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="alternate" type="application/rss+xml" title="The Zygor Guides News Feed" href="http://feeds.feedburner.com/zygorguides" />
<style type='text/css' media='screen'>
<!--
@import url(../css/peach.css);
#content {
width: 790px;
}

#main {
padding: 50px;
padding-top: 20px;
}

.talents {
list-style-type: none;
}

.talents li {
margin-left: 25px;
font-size: 1.1em;
line-height: 1.5em;
}

textarea {
		background: #e2d3ca;
		border: 1px solid #333;
		font-family: Georgia, Helvetica, sans-serif;
		font-size: 0.9em;
		color: #000;
		padding: 2px;
		padding-bottom: 1px;
		}
.style2 {
	font-size: 14px;
	font-weight: bold;
}
.style3 {font-size: 14px}
.style4 {
	font-size: 1em;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style7 {font-family: Verdana, Arial, Helvetica, sans-serif}



-->
</style>
<script type="text/javascript" src="../js/flashembed.js"></script>
<script type="text/javascript" src="../js/dropdown.js"></script>
<script src="http://www.wowhead.com/widgets/power.js"></script>
</head>
<body>
<div id="container">
<div id="header"></div>
<div id="navigation">
<ul>
<li><a href="http://www.zygorguides.com" onclick="" onmouseover="dropdownmenu(this, event, menu1, '150px')" onmouseout="delayhidemenu()">Home</a></li>
<li><a href="../news/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu2, '150px')" onmouseout="delayhidemenu()">News</a></li>
<li><a href="../about/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu3, '150px')" onmouseout="delayhidemenu()">About</a></li>
<li><a href="../guides/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu4, '150px')" onmouseout="delayhidemenu()">Guides</a></li>
<li><a href="../freetrial/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu5, '150px')" onmouseout="delayhidemenu()">Freebies</a></li>
<li><a href="../amember/member.php" onclick="" onmouseover="dropdownmenu(this, event, menu6, '150px')" onmouseout="delayhidemenu()">Members Area</a></li>
<li><a href="../forum/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu7, '150px')" onmouseout="delayhidemenu()">Forum</a></li>
<li><a href="../faq/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu8, '150px')" onmouseout="delayhidemenu()">FAQ</a></li>
<li><a href="../contact/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu9, '150px')" onmouseout="delayhidemenu()">Contact</a></li>
</ul>
</div>
<div id="content">
<div id="main">
<div class="bigtext">Food &amp; Drink Stats Guide</div>
<p><span class="style3">Skip to the</span> <span class="style2"><a href="#toc"> Table of Contents</a></span></p>
<h3>Overview:<br />
</h3>
<p> <img src="../img/bread.png" alt="bread" width="300" height="132" class="imgleft" /> <strong>Bread</strong> is made from baked dough and is one of the six main types of <a href="http://www.wowwiki.com/Food" title="Food">food</a> in WoW. Hunters can feed bread to some pets. Players can loot bread from dead humanoids and from chests. Bread can be recieved as quest rewards. Players can purchase bread from bread vendors. Bread is unique among foods in that it can be conjured by mages.  Some bread type foods can be created by cooks. <br />
    <br />
  </p>
  <p><img src="../img/fish.png" alt="fish" width="300" height="132" class="imgright" /><strong>Fish</strong> can be eaten raw (restore hit points when eaten). If you have the cooking secondary skill, you can cook many fish to increase their food value (restore more hit points when eaten). Certain fish grant various temporary buffs when cooked and eaten. Players can loot fish from dead mobs, especially aquatic or semi-aquatic mobs. Murlocs in particular often drop fish. Players can purchase fish from fish vendors.Hunters can feed fish to some pets, cats for example.<br />
    <br />
  </p>
  <p><img src="../img/fungi.png" alt="fungi" width="300" height="132" class="imgleft" /><strong>Fungi</strong> are edible sporebearers, and is one of the six main types of food in WoW. Player Characters can eat fungus to recover health. (No fungus items provide a Well Fed buff at this time.) Hunters can feed fungus to some pets, including bats and gorillas. Players can loot fungus from dead humanoids and from chests. Fungus can be gotten as quest rewards. Players can purchase fungus from fungus vendors. <br />
    <br />
  </p>
  <p><img src="../img/meat.png" alt="meat" width="300" height="132" class="imgright" /><strong>Meat</strong> is the edible flesh of animals in and is one of the six main types of food WoW. Players can frequently loot meat (flesh) from dead beast mobs. Because of this, hunter pets that only eat meat, which is the most restrictive hunter pet diet, are actually easy to feed. Players can loot edible meat (carried food) from dead humanoid mobs and from chests. Edible meat can be recieved as quest rewards. Players can purchase edible meat from meat vendors. Many meat type foods can be created by cooking. Since meat drops so frequently from beasts, and meat can be traded, the auction house is always a good source. <br />
      <br />
  </p>
  <p><img src="../img/cheese.png" alt="cheese" width="300" height="132" class="imgleft" /><strong>Cheese</strong> is made from curdled animal milk and is one of the six main types of food in WoW.Players can loot cheese from dead humanoids and from chests. A few quests give cheese as a reward. Players can purchase cheese from cheese vendors. A quick survey of Cooking recipes does not show any cheese type foods that can be created by cooks at this time. <br />
    <br />
    <br />
  </p>
  <p><img src="../img/fruit.png" alt="fruit" width="300" height="132" class="imgright" /><strong>Fruit</strong> are sweet and fleshy seedpods, and are one of the six main types of food in WoW. Players can loot fruit from dead humanoids and from chests. Fruit can be gotten as quest rewards. Players can purchase fruit from fruit vendors. Player Characters can eat fruit to recover health. (No fruit items provide a Well Fed buff at this time).Hunters can feed fruit to some pets, including bats and gorillas. Some edible fruit items are used as ingredients for foods that can be created by cooking. <br />
    <br />
  </p>
  <p><img src="../img/drink.png" alt="drink" width="300" height="132" class="imgleft" /><strong>Drinks</strong> are beverage items that your character can consume by sitting down that restore mana over a specified time period. Drink items can be received as Quest rewards, purchased from vendors, created with cooking, found in containers such as Water Barrels and Milk Barrels, and summoned by Mages.<br />
    <br />
      </p>
  <p><br />
  </p>
  <p>&nbsp;</p>
  <h2><a name="toc" id="toc"></a>Table of Contents</h2>

<p><a href="#deathknight"><img src="../img/tocdk.gif" alt="tocdk" width="244" height="50" class="imageborder" /></a><a href="#priest"><img src="../img/tocpriest.gif" alt="tocpriest" width="244" height="50" class="tocimg" /></a><br />
  <br />
  <a href="#druid"><img src="../img/tocdruid.gif" alt="tocdruid" width="244" height="50" class="imageborder" /></a><a href="#rogue"><img src="../img/tocrogue.gif" alt="tocrogue" width="244" height="50" class="tocimg" /></a><br />
  <br />
  <a href="#hunter"><img src="../img/tochunt.gif" alt="tochunt" width="244" height="50" class="imageborder" /></a><a href="#shaman"><img src="../img/tocsham.gif" alt="tocsham" width="244" height="50" class="tocimg" /></a><br />
  <br />
  <a href="#mage"><img src="../img/tocmage.gif" alt="tcmage" width="244" height="50" class="imageborder" /></a><a href="#warlock"><img src="../img/tocwar.gif" alt="tocwarlock" width="244" height="50" class="tocimg" /></a><br />
  <br />
  <a href="#paladin"><img src="../img/tocpala.gif" alt="tocpala" width="244" height="50" class="imageborder" /></a><a href="#warrior"><img src="../img/tocwarrior.gif" alt="tocwarrior" width="244" height="50" class="tocimg" /></a><br />
  <br />
</p>
<h2><a name="deathknight" id="deathknight"></a>Death Knight<br />
</h2>


<p><strong class="ul topicdetails style4">Level 45</strong><br />
  <a href="http://www.wowhead.com/?item=20452"><strong>Smoked Desert Dumplings</strong></a><br />
  Increases Strength by 20 for 15 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=13928"><strong>Grilled Squid</strong></a><br />
  Increases Agility by 10 for 10 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=35563"><strong>Charred Bear Kabobs</strong></a><br />
  Increases Attack Power by 24 for 15 minutes</p>
<p><span class="ul style6">Level 55</span><br />
  <a href="http://www.wowhead.com/?item=27658"><strong>Roasted Clefthoof</strong></a><br />
  Increases Strength by 20 for 30 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=29292"><strong>Helboar Bacon</strong></a><br />
  Increases Strength by 20 for 15 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=27664"><strong>Grilled Mudfish</strong></a>, <a href="http://www.wowhead.com/?item=27659"><strong>Warp Burger</strong></a><br />
  Increases Agility by 20 for 30 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=27655"><strong>Ravager Dog</strong></a><br />
  Increases Attack Power by 40 for 30 mins</p>
<p><strong class="ul style7">Level 65</strong><br />
  <a href="http://www.wowhead.com/?item=33874"><strong>Kiblers Bits</strong></a><br />
  Increases Strength by 20 for 1 hour<br />
  <br />
  <a href="http://www.wowhead.com/?item=30359"><strong>Oronok’s Tuber of Strength</strong></a><br />
  Increases Strength by 20 for 30 mins</p>
<p><a href="http://www.wowhead.com/?item=30358"><strong>Oronok’s Tuber of Agility</strong></a><br />
  Increases Agility by 20 for 30 mins</p>
<p><strong class="ul style7">Level 70</strong><br />
  <a href="http://www.wowhead.com/?item=43000"><strong>Dragonfin Filet</strong></a><br />
  Increases Strength and Stamina by 40 for 1 hour<br />
  <br />
  <a href="http://www.wowhead.com/?item=42999"><strong>Blackened Dragonfin</strong></a><br />
  Increases Agility and Stamina by 40 for 1 hour<br />
  <br />
  <a href="http://www.wowhead.com/?item=34762"><strong>Grilled Sculpin</strong></a><br />
  Increases Attack Power by 60 for 1 hour</p>
<p><a href="http://www.wowhead.com/?item=34748"><strong>Mammoth Meal</strong></a><br />
  Increases Attack Power by 60 for 1 hour</p>
<p><a href="http://www.wowhead.com/?item=34754"><strong>Mega Mammoth Meal</strong></a><br />
  Increases Attack Power by 80 for 1 hour</p>
<p><a href="http://www.wowhead.com/?item=34766"><strong>Poached Northern Sculpin</strong></a><br />
  Increases Attack Power by 80 for 1 hour<br />
  <br />
</p>
<br />
<h2><a name="druid" id="druid"></a>Druid</h2>

<p><strong class="ul style7">Level 1</strong><br />
  <a href="http://www.wowhead.com/?item=12224"><strong>Crispy Bat Wing</strong></a>, <a href="http://www.wowhead.com/?item=17197"><strong>Gingerbread Cookie</strong></a>, <a href="http://www.wowhead.com/?item=6888"><strong>Herb Baked Egg</strong></a>, <a href="http://www.wowhead.com/?item=27635"><strong>Lynx Steak</strong></a>, <a href="http://www.wowhead.com/?item=24105"><strong>Roasted Moongraze Tenderloin</strong></a>, <a href="http://www.wowhead.com/?item=2888"><strong>Beer Basted Boar Ribs</strong></a>, <a href="http://www.wowhead.com/?item=5472"><strong>Kaldorei Spider Kabob</strong></a>, <a href="http://www.wowhead.com/?item=2680"><strong>Spiced Wolf Meat</strong></a>, <a href="http://www.wowhead.com/?item=17198"><strong>Egg Nog</strong></a>, <a href="http://www.wowhead.com/?item=5484"><strong>Roasted Kodo Meat</strong></a><br />
  Increases 2 Strength and Stamina for 15 mins<br />
  <br />
  <strong class="ul style7">Level 5</strong><br />
  <a href="http://www.wowhead.com/?item=27636"><strong>Bat Bites</strong></a>, <a href="http://www.wowhead.com/?item=5525"><strong>Boiled Clams</strong></a>, <a href="http://www.wowhead.com/?item=2684"><strong>Coyote Steak</strong></a>, <a href="http://www.wowhead.com/?item=5476"><strong>Fillet of Frenzy</strong></a>, <a href="http://www.wowhead.com/?item=724"><strong>Goretusk Liver Pie</strong></a>, <a href="http://www.wowhead.com/?item=5477"><strong>Strider Stew</strong></a>, <a href="http://www.wowhead.com/?item=3220"><strong>Blood Sausage</strong></a>, <strong><a href="http://www.wowhead.com/?item=22645">Crunchy Spider Surprise</a></strong>, <a href="http://www.wowhead.com/?item=2683"><strong>Crab Cake</strong></a>, <a href="http://www.wowhead.com/?item=3662"><strong>Crocolisk Steak</strong></a>, <a href="http://www.wowhead.com/?item=2687"><strong>Dry Pork Ribs</strong></a><br />
  Increases 4 Strength and Stamina for 15 mins<br />
  <br />
  <span class="ul style7"><strong>Level 10</strong></span><br />
  <a href="http://www.wowhead.com/?item=2699"><strong>Redridge Goulash</strong></a><br />
  Increases 6 Strength and Stamina for 15 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=21072"><strong>Smoked Sagefish</strong></a><br />
  Increases Mana Regeneration by 3 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 12</strong><br />
  <a href="http://www.wowhead.com/?item=5479"><strong>Crispy Lizard Tail</strong></a><br />
  Increases 6 Strength and Stamina for 15 mins</p>
<p><strong class="ul style7">Level 15</strong><br />
  <a href="http://www.wowhead.com/?item=3663"><strong>Murloc Fin Soup</strong></a>, <a href="http://www.wowhead.com/?item=1017"><strong>Seasoned Wolf Kabob</strong></a>, <a href="http://www.wowhead.com/?item=3726"><strong>Big Bear Steak</strong></a>, <a href="http://www.wowhead.com/?item=3666"><strong>Gooey Spider Cake</strong></a>, <a href="http://www.wowhead.com/?item=5480"><strong>Lean Venison</strong></a>, <a href="http://www.wowhead.com/?item=3664"><strong>Crocolisk Gumbo</strong></a>, <a href="http://www.wowhead.com/?item=5527"><strong>Goblin Deviled Clams</strong></a>, <a href="http://www.wowhead.com/?item=3727"><strong>Hot Lion Chops</strong></a>, <a href="http://www.wowhead.com/?item=12209"><strong>Lean Wolf Steak</strong></a>, <a href="http://www.wowhead.com/?item=3665"><strong>Curiously Tasty Omelet</strong></a><br />
  Increases Strength and Stamina by 6 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 20</strong><br />
  <a href="http://www.wowhead.com/?item=20074"><strong>Heavy Crocolisk Stew</strong></a>, <a href="http://www.wowhead.com/?item=3728"><strong>Tasty Lion Steak</strong></a><br />
  Increases Strength and Stamina by 8 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 25</strong><br />
  <a href="http://www.wowhead.com/?item=4457"><strong>Barbecued Buzzard Wing</strong></a>, <a href="http://www.wowhead.com/?item=12213"><strong>Carrion Surprise</strong></a>, <a href="http://www.wowhead.com/?item=6038"><strong>Giant Clam Scorcho</strong></a>, <a href="http://www.wowhead.com/?item=13851"><strong>Hot Wolf Ribs</strong></a>, <a href="http://www.wowhead.com/?item=12212"><strong>Jungle Stew</strong></a>, <a href="http://www.wowhead.com/?item=12214"><strong>Mystery Stew</strong></a>,<a href="http://www.wowhead.com/?item=12210"><strong> Roast Raptor</strong></a>, <a href="http://www.wowhead.com/?item=3729"><strong>Soothing Turtle Bisque</strong></a><br />
  Increases Strength and Stamina by 8 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 30</strong><br />
  <a href="http://www.wowhead.com/?item=21217"><strong>Sagefish Delight</strong></a><br />
  Increases Mana Regeneration by 6 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 35</strong><br />
  <a href="http://www.wowhead.com/?item=13928"><strong>Grilled Squid</strong></a><br />
  Increases Strength and Stamina</p>
<p><strong class="ul style7">Level 45</strong><br />
  <a href="http://www.wowhead.com/?item=20452"><strong>Smoked Desert Dumplings</strong></a><br />
  Increases Strength by 20 for 15 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=35563"><strong>Charred Bear Kabobs</strong></a><br />
  Increases Attack Power by 24 for 15 minutes</p>
<p><strong class="ul style7">Level 55</strong><br />
  <a href="http://www.wowhead.com/?item=27658"><strong>Roasted Clefthoof</strong></a><br />
  Increases Strength by 20 for 30 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=29292"><strong>Helboar Bacon</strong></a><br />
  Increases Strength by 20 for 15 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=27664"><strong>Grilled Mudfish</strong></a>, <a href="http://www.wowhead.com/?item=27659"><strong>Warp Burger</strong></a><br />
  Increases Agility by 20 for 30 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=27655"><strong>Ravager Dog</strong></a><br />
  Increases Attack Power by 40 for 30 mins<br />
  <br />
  <strong class="ul style7">Level 65</strong><br />
  <a href="http://www.wowhead.com/?item=33874"><strong>Kiblers Bits</strong></a><br />
  Increases Strength by 20 for 1 hour<br />
  <br />
  <a href="http://www.wowhead.com/?item=30359"><strong>Oronok’s Tuber of Strength</strong></a><br />
  Increases Strength by 20 for 30 mins</p>
<p><a href="http://www.wowhead.com/?item=30358"><strong>Oronok’s Tuber of Agility</strong></a><br />
  Increases Agility by 20 for 30 mins<br />
  <br />
  <strong class="ul style7">Level 70</strong><br />
  <a href="http://www.wowhead.com/?item=43000"><strong>Dragonfin Filet</strong></a><br />
  Increases Strength and Stamina by 40 for 1 hour<br />
  <br />
  <a href="http://www.wowhead.com/?item=42999"><strong>Blackened Dragonfin</strong></a><br />
  Increases Agility and Stamina by 40 for 1 hour<br />
  <br />
  <a href="http://www.wowhead.com/?item=34762"><strong>Grilled Sculpin</strong></a><br />
  Increases Attack Power by 60 for 1 hour</p>
<p><a href="http://www.wowhead.com/?item=34748"><strong>Mammoth Meal</strong></a><br />
  Increases Attack Power by 60 for 1 hour</p>
<p><a href="http://www.wowhead.com/?item=34754"><strong>Mega Mammoth Meal</strong></a><br />
  Increases Attack Power by 80 for 1 hour</p>
<p><a href="http://www.wowhead.com/?item=34766"><strong>Poached Northern Sculpin</strong></a><br />
  Increases Attack Power by 80 for 1 hour<br />
  <br />
  <br />
</p>
<h2><a name="hunter" id="hunter"></a>Hunter</h2>

<p><strong class="ul style7">Level 1</strong><br />
  <a href="http://www.wowhead.com/?item=12224"><strong>Crispy Bat Wing</strong></a>, <a href="http://www.wowhead.com/?item=17197"><strong>Gingerbread Cookie</strong></a>, <a href="http://www.wowhead.com/?item=6888"><strong>Herb Baked Egg</strong></a>, <a href="http://www.wowhead.com/?item=27635"><strong>Lynx Steak</strong></a>, <a href="http://www.wowhead.com/?item=24105"><strong>Roasted Moongraze Tenderloin</strong></a>, <a href="http://www.wowhead.com/?item=2888"><strong>Beer Basted Boar Ribs</strong></a>, <a href="http://www.wowhead.com/?item=5472"><strong>Kaldorei Spider Kabob</strong></a>, <a href="http://www.wowhead.com/?item=2680"><strong>Spiced Wolf Meat</strong></a>, <a href="http://www.wowhead.com/?item=17198"><strong>Egg Nog</strong></a>, <a href="http://www.wowhead.com/?item=5484"><strong>Roasted Kodo Meat</strong></a><br />
Increases 2 Strength and Stamina for 15 mins<br />
<br />
<strong class="ul style7">Level 5</strong><br />
<a href="http://www.wowhead.com/?item=27636"><strong>Bat Bites</strong></a>, <a href="http://www.wowhead.com/?item=5525"><strong>Boiled Clams</strong></a>, <a href="http://www.wowhead.com/?item=2684"><strong>Coyote Steak</strong></a>, <a href="http://www.wowhead.com/?item=5476"><strong>Fillet of Frenzy</strong></a>, <a href="http://www.wowhead.com/?item=724"><strong>Goretusk Liver Pie</strong></a>, <a href="http://www.wowhead.com/?item=5477"><strong>Strider Stew</strong></a>, <a href="http://www.wowhead.com/?item=3220"><strong>Blood Sausage</strong></a>, <strong><a href="http://www.wowhead.com/?item=22645">Crunchy Spider Surprise</a></strong>, <a href="http://www.wowhead.com/?item=2683"><strong>Crab Cake</strong></a>, <a href="http://www.wowhead.com/?item=3662"><strong>Crocolisk Steak</strong></a>, <a href="http://www.wowhead.com/?item=2687"><strong>Dry Pork Ribs</strong></a><br />
Increases 4 Strength and Stamina for 15 mins<br />
  <br />
  <strong class="ul style7">Level 10</strong><br />
  <a href="http://www.wowhead.com/?item=1082"><strong>Redridge Goulash</strong></a><br />
  Increases 6 Strength and Stamina for 15 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=21072"><strong>Smoked Sagefish</strong></a><br />
  Increases Mana Regeneration by 3 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 12</strong><br />
  <a href="http://www.wowhead.com/?item=5479"><strong>Crispy Lizard Tail</strong></a><br />
  Increases 6 Strength and Stamina for 15 mins</p>
<p><strong class="ul style7">Level 15</strong><br />
  <a href="http://www.wowhead.com/?item=3663"><strong>Murloc Fin Soup</strong></a>, <a href="http://www.wowhead.com/?item=1017"><strong>Seasoned Wolf Kabob</strong></a>, <a href="http://www.wowhead.com/?item=3726"><strong>Big Bear Steak</strong></a>, <a href="http://www.wowhead.com/?item=3666"><strong>Gooey Spider Cake</strong></a>, <a href="http://www.wowhead.com/?item=5480"><strong>Lean Venison</strong></a>, <a href="http://www.wowhead.com/?item=3664"><strong>Crocolisk Gumbo</strong></a>, <a href="http://www.wowhead.com/?item=5527"><strong>Goblin Deviled Clams</strong></a>, <a href="http://www.wowhead.com/?item=3727"><strong>Hot Lion Chops</strong></a>, <a href="http://www.wowhead.com/?item=12209"><strong>Lean Wolf Steak</strong></a>, <a href="http://www.wowhead.com/?item=3665"><strong>Curiously Tasty Omelet</strong></a><br />
Increases Strength and Stamina by 6 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 20</strong><br />
  <a href="http://www.wowhead.com/?item=20074"><strong>Heavy Crocolisk Stew</strong></a>, <a href="http://www.wowhead.com/?item=3728"><strong>Tasty Lion Steak</strong></a><br />
  Increases Strength and Stamina by 8 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 25</strong><br />
  <a href="http://www.wowhead.com/?item=4457"><strong>Barbecued Buzzard Wing</strong></a>, <a href="http://www.wowhead.com/?item=12213"><strong>Carrion Surprise</strong></a>, <a href="http://www.wowhead.com/?item=6038"><strong>Giant Clam Scorcho</strong></a>, <a href="http://www.wowhead.com/?item=13851"><strong>Hot Wolf Ribs</strong></a>, <strong><a href="http://www.wowhead.com/?item=12212">Jungle Stew</a></strong>, <a href="http://www.wowhead.com/?item=12214"><strong>Mystery Stew</strong></a>, <a href="http://www.wowhead.com/?item=12210"><strong>Roast Raptor</strong></a>, <a href="http://www.wowhead.com/?item=3729"><strong>Soothing Turtle Bisque</strong></a><br />
  Increases Strength and Stamina by 8 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 30</strong><br />
  <a href="http://www.wowhead.com/?item=21217"><strong>Sagefish Delight</strong></a><br />
  Increases Mana Regeneration by 6 for 15 mins<br />
  <br />
  <strong class="ul style7">Level 35</strong><br />
  <a href="http://www.wowhead.com/?item=13931"><strong>Nightfin Soup</strong></a><br />
  Increases Mana Regeneration by 6 for 10 mins</p>
<p><strong class="ul style7">Level 45</strong><br />
  <a href="http://www.wowhead.com/?item=35563"><strong>Charred Bear Kabobs</strong></a><br />
  Increases Attack Power by 24 for 15 minutes</p>
<p><span class="ul style7"><strong>Level 55</strong></span><strong><br />
</strong><a href="http://www.wowhead.com/?item=27664"><strong>Grilled Mudfish</strong></a>, <a href="http://www.wowhead.com/?item=27659"><strong>Warp Burger</strong></a><br />
  Increases Agility by 20 for 30 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=27655"><strong>Ravager Dog</strong></a><br />
  Increases Attack Power by 40 for 30 mins<br />
  <br />
  <strong class="ul style7">Level 65</strong><br />
  <a href="http://www.wowhead.com/?item=33872"><strong>Spicy Hot Talbuk</strong></a><br />
  Increases Hit Rating by 20 for 30 mins</p>
<p><a href="http://www.wowhead.com/?item=30358"><strong>Oronok’s Tuber of Agility</strong></a><br />
  Increases Agility by 20 for 30 mins<br />
  <br />
  <a href="http://www.wowhead.com/?item=33825"><strong>Skullfish Soup</strong></a><br />
  Increases Critical Strike rating by 20 for 30 mins<br />
  <br />
  <strong class="ul style7">Level 70</strong><br />
  <a href="http://www.wowhead.com/?item=42996"><strong>Snapper Extreme</strong></a><br />
  Increases Stamina by 40 and Hit Rating by 40 for 1 hour<br />
  <br />
  <a href="http://www.wowhead.com/?item=44953"><strong>Worg Tartare</strong></a><br />
  Increases Stamina by 40 and Hit Rating by 40 for 1 hour<br />
  <br />
  <strong><a href="http://www.wowhead.com/?item=42999">Blackened Dragonfin</a></strong><br />
  Increases Agility and Stamina by 40 for 1 hour<br />
  <br />
  <a href="http://www.wowhead.com/?item=34762"><strong>Grilled Sculpin</strong></a>, <a href="http://www.wowhead.com/?item=34748"><strong>Mammoth Meal</strong></a><br />
  Increases Attack Power by 60 for 1 hour</p>
<p><a href="http://www.wowhead.com/?item=34754"><strong>Mega Mammoth Meal</strong></a>, <a href="http://www.wowhead.com/?item=34766"><strong>Poached Northern Sculpin</strong></a><br />
  Increases Attack Power by 80 for 1 hour<br />
  <br />
  <strong><a href="http://www.wowhead.com/?item=34764">Poached Nettlefish</a></strong><br />
  Increases Critical Strike rating by 30 for 1 hour<br />
</p>
<br />
<br />
<h2><a name="mage" id="mage"></a>Mage</h2>

  <p><strong class="ul style7">Level 1</strong><br />
    <a href="http://www.wowhead.com/?item=12224"><strong>Crispy Bat Wing</strong></a>, <a href="http://www.wowhead.com/?item=17197"><strong>Gingerbread Cookie</strong></a>, <a href="http://www.wowhead.com/?item=6888"><strong>Herb Baked Egg</strong></a>, <a href="http://www.wowhead.com/?item=27635"><strong>Lynx Steak</strong></a>, <a href="http://www.wowhead.com/?item=24105"><strong>Roasted Moongraze Tenderloin</strong></a>, <a href="http://www.wowhead.com/?item=2888"><strong>Beer Basted Boar Ribs</strong></a>, <a href="http://www.wowhead.com/?item=5472"><strong>Kaldorei Spider Kabob</strong></a>, <a href="http://www.wowhead.com/?item=2680"><strong>Spiced Wolf Meat</strong></a>, <a href="http://www.wowhead.com/?item=17198"><strong>Egg Nog</strong></a>, <a href="http://www.wowhead.com/?item=5484"><strong>Roasted Kodo Meat</strong></a><br />
Increases 2 Strength and Stamina for 15 mins<br />
<br />
<strong class="ul style7">Level 5</strong><br />
<a href="http://www.wowhead.com/?item=27636"><strong>Bat Bites</strong></a>, <a href="http://www.wowhead.com/?item=5525"><strong>Boiled Clams</strong></a>, <a href="http://www.wowhead.com/?item=2684"><strong>Coyote Steak</strong></a>, <a href="http://www.wowhead.com/?item=5476"><strong>Fillet of Frenzy</strong></a>, <a href="http://www.wowhead.com/?item=724"><strong>Goretusk Liver Pie</strong></a>, <a href="http://www.wowhead.com/?item=5477"><strong>Strider Stew</strong></a>, <a href="http://www.wowhead.com/?item=3220"><strong>Blood Sausage</strong></a>, <strong><a href="http://www.wowhead.com/?item=22645">Crunchy Spider Surprise</a></strong>, <a href="http://www.wowhead.com/?item=2683"><strong>Crab Cake</strong></a>, <a href="http://www.wowhead.com/?item=3662"><strong>Crocolisk Steak</strong></a>, <a href="http://www.wowhead.com/?item=2687"><strong>Dry Pork Ribs</strong></a><br />
Increases 4 Strength and Stamina for 15 mins<br />
    <br />
    <strong class="ul style7">Level 10</strong><br />
    <a href="http://www.wowhead.com/?item=1082"><strong>Redridge Goulash</strong></a><br />
Increases 6 Strength and Stamina for 15 mins<br />
<br />
<a href="http://www.wowhead.com/?item=21072"><strong>Smoked Sagefish</strong></a><br />
Increases Mana Regeneration by 3 for 15 mins<br />
<br />
<strong class="ul style7">Level 12</strong><br />
<a href="http://www.wowhead.com/?item=5479"><strong>Crispy Lizard Tail</strong></a><br />
Increases 6 Strength and Stamina for 15 mins</p>
  <p><strong class="ul style7">Level 15</strong><br />
    <a href="http://www.wowhead.com/?item=3663"><strong>Murloc Fin Soup</strong></a>, <a href="http://www.wowhead.com/?item=1017"><strong>Seasoned Wolf Kabob</strong></a>, <a href="http://www.wowhead.com/?item=3726"><strong>Big Bear Steak</strong></a>, <a href="http://www.wowhead.com/?item=3666"><strong>Gooey Spider Cake</strong></a>, <a href="http://www.wowhead.com/?item=5480"><strong>Lean Venison</strong></a>, <a href="http://www.wowhead.com/?item=3664"><strong>Crocolisk Gumbo</strong></a>, <a href="http://www.wowhead.com/?item=5527"><strong>Goblin Deviled Clams</strong></a>, <a href="http://www.wowhead.com/?item=3727"><strong>Hot Lion Chops</strong></a>, <a href="http://www.wowhead.com/?item=12209"><strong>Lean Wolf Steak</strong></a>, <a href="http://www.wowhead.com/?item=3665"><strong>Curiously Tasty Omelet</strong></a><br />
Increases Strength and Stamina by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 20</strong><br />
    <a href="http://www.wowhead.com/?item=20074"><strong>Heavy Crocolisk Stew</strong></a>, <a href="http://www.wowhead.com/?item=3728"><strong>Tasty Lion Steak</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 25</strong><br />
    <a href="http://www.wowhead.com/?item=4457"><strong>Barbecued Buzzard Wing</strong></a>, <a href="http://www.wowhead.com/?item=12213"><strong>Carrion Surprise</strong></a>, <a href="http://www.wowhead.com/?item=6038"><strong>Giant Clam Scorcho</strong></a>, <a href="http://www.wowhead.com/?item=13851"><strong>Hot Wolf Ribs</strong></a>, <a href="http://www.wowhead.com/?item=12212"><strong>Jungle Stew</strong></a>, <a href="http://www.wowhead.com/?item=12214"><strong>Mystery Stew</strong></a>,<a href="http://www.wowhead.com/?item=12210"><strong> Roast Raptor</strong></a>, <a href="http://www.wowhead.com/?item=3729"><strong>Soothing Turtle Bisque</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 30</strong><br />
    <a href="http://www.wowhead.com/?item=21217"><strong>Sagefish Delight</strong></a><br />
    Increases Mana Regeneration by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 35</strong><br />
    <strong><a href="http://www.wowhead.com/?item=13931">Nightfin Soup</a></strong><br />
    Increases Mana Regeneration by 6 for 10 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=33004"><strong>Clamlette Magnifique</strong></a><br />
    Increases Attack Power and 14 Spell Power for 1 hour<br />
    <br />
    <strong class="ul style7">Level 45</strong><br />
    <a href="http://www.wowhead.com/?item=18254"><strong>Runn Tum Tuber Surprise</strong></a><br />
    Increases Intellect 10 for 10 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=35565"><strong>Juicy Bear Burger</strong></a><br />
    Increases Spell Power by 14 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 55</strong><br />
    <strong><a href="http://www.wowhead.com/?item=27657">Blackened Basilisk</a></strong><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=31673"><strong>Crunchy Serpent</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27666"><strong>Golden Fish Sticks</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27665"><strong>Poached Bluefish</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins</p>
  <p><a href="http://www.wowhead.com/?item=27663"><strong>Blackened Sporefish</strong></a><br />
    Increases Mana Regeneration by 8 for 30 mins<br />
    <br />
    <strong class="ul style7">Level 65</strong><br />
    <a href="http://www.wowhead.com/?item=27657"><strong>Blackened Basilisk</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=33825"><strong>Skullfish Soup</strong></a><br />
    Increases Critical Strike by 20 for 30 mins<br />
    <br />
    <strong class="ul style7">Level 70</strong><br />
    <a href="http://www.wowhead.com/?item=30357"><strong>Oronok's Tuber of Healing</strong></a><br />
    Increases Spell Power by<br />
    23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=30361"><strong>Oronok's Tuber of Spell Power</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=34767"><strong>Firecracker Salmon</strong></a><br />
    Increases Spell Power by 46 and 40 Stamina for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34749"><strong>Shoveltusk Steak</strong></a><br />
    Increases Spell Power by 46 and 40 Stamina for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34763"><strong>Smoked Salmon</strong></a><br />
    Increases Spell Power by 35 and 40 Stamina for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34755"><strong>Tender Shoveltusk Steak</strong></a><br />
    Increases Spell Power by 46 and 40 Stamina for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34764"><strong>Poached Nettlefish</strong></a><br />
    Increases Critical Strike by 30 for 1 hour<br />
    <a href="http://www.wowhead.com/?item=34756"><strong><br />
    Spiced Worm Burger</strong></a><br />
    Increases Critical Strike by 40 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34768"><strong>Spicy Blue Nettlefish</strong></a><br />
    Increases Critical Strike by 40 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=39691"><strong>Succulent Orca Stew</strong></a> <br />
    Increases Critical Strike by 30 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34750"><strong>Worm Delight</strong></a><br />
    Increases Criticlal Strike by 30 for 1 hour<br />
    <br />
  </p>
  <h2><a name="paladin" id="paladin"></a>Paladin</h2>

  <p><strong class="ul style7">Level 1</strong><br />
    <a href="http://www.wowhead.com/?item=12224"><strong>Crispy Bat Wing</strong></a>, <a href="http://www.wowhead.com/?item=17197"><strong>Gingerbread Cookie</strong></a>, <a href="http://www.wowhead.com/?item=6888"><strong>Herb Baked Egg</strong></a>, <a href="http://www.wowhead.com/?item=27635"><strong>Lynx Steak</strong></a>, <a href="http://www.wowhead.com/?item=24105"><strong>Roasted Moongraze Tenderloin</strong></a>, <a href="http://www.wowhead.com/?item=2888"><strong>Beer Basted Boar Ribs</strong></a>, <a href="http://www.wowhead.com/?item=5472"><strong>Kaldorei Spider Kabob</strong></a>, <a href="http://www.wowhead.com/?item=2680"><strong>Spiced Wolf Meat</strong></a>, <a href="http://www.wowhead.com/?item=17198"><strong>Egg Nog</strong></a>, <a href="http://www.wowhead.com/?item=5484"><strong>Roasted Kodo Meat</strong></a><br />
Increases 2 Strength and Stamina for 15 mins<br />
<br />
<strong class="ul style7">Level 5</strong><br />
<a href="http://www.wowhead.com/?item=27636"><strong>Bat Bites</strong></a>, <a href="http://www.wowhead.com/?item=5525"><strong>Boiled Clams</strong></a>, <a href="http://www.wowhead.com/?item=2684"><strong>Coyote Steak</strong></a>, <a href="http://www.wowhead.com/?item=5476"><strong>Fillet of Frenzy</strong></a>, <a href="http://www.wowhead.com/?item=724"><strong>Goretusk Liver Pie</strong></a>, <a href="http://www.wowhead.com/?item=5477"><strong>Strider Stew</strong></a>, <a href="http://www.wowhead.com/?item=3220"><strong>Blood Sausage</strong></a>, <strong><a href="http://www.wowhead.com/?item=22645">Crunchy Spider Surprise</a></strong>, <a href="http://www.wowhead.com/?item=2683"><strong>Crab Cake</strong></a>, <a href="http://www.wowhead.com/?item=3662"><strong>Crocolisk Steak</strong></a>, <a href="http://www.wowhead.com/?item=2687"><strong>Dry Pork Ribs</strong></a><br />
Increases 4 Strength and Stamina for 15 mins<br />
    <br />
    <strong class="ul style7">Level 10</strong><br />
    <a href="http://www.wowhead.com/?item=1082"><strong>Redridge Goulash</strong></a><br />
Increases 6 Strength and Stamina for 15 mins<br />
<br />
<a href="http://www.wowhead.com/?item=21072"><strong>Smoked Sagefish</strong></a><br />
Increases Mana Regeneration by 3 for 15 mins<br />
<br />
<strong class="ul style7">Level 12</strong><br />
<a href="http://www.wowhead.com/?item=5479"><strong>Crispy Lizard Tail</strong></a><br />
Increases 6 Strength and Stamina for 15 mins</p>
  <p><strong class="ul style7">Level 15</strong><br />
    <a href="http://www.wowhead.com/?item=3663"><strong>Murloc Fin Soup</strong></a>, <a href="http://www.wowhead.com/?item=1017"><strong>Seasoned Wolf Kabob</strong></a>, <a href="http://www.wowhead.com/?item=3726"><strong>Big Bear Steak</strong></a>, <a href="http://www.wowhead.com/?item=3666"><strong>Gooey Spider Cake</strong></a>, <a href="http://www.wowhead.com/?item=5480"><strong>Lean Venison</strong></a>, <a href="http://www.wowhead.com/?item=3664"><strong>Crocolisk Gumbo</strong></a>, <a href="http://www.wowhead.com/?item=5527"><strong>Goblin Deviled Clams</strong></a>, <a href="http://www.wowhead.com/?item=3727"><strong>Hot Lion Chops</strong></a>, <a href="http://www.wowhead.com/?item=12209"><strong>Lean Wolf Steak</strong></a>, <a href="http://www.wowhead.com/?item=3665"><strong>Curiously Tasty Omelet</strong></a><br />
Increases Strength and Stamina by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 20</strong><br />
    <a href="http://www.wowhead.com/?item=20074"><strong>Heavy Crocolisk Stew</strong></a>, <a href="http://www.wowhead.com/?item=3728"><strong>Tasty Lion Steak</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 25</strong><br />
    <a href="http://www.wowhead.com/?item=4457"><strong>Barbecued Buzzard Wing</strong></a>, <a href="http://www.wowhead.com/?item=12213"><strong>Carrion Surprise</strong></a>, <a href="http://www.wowhead.com/?item=6038"><strong>Giant Clam Scorcho</strong></a>, <a href="http://www.wowhead.com/?item=13851"><strong>Hot Wolf Ribs</strong></a>, <a href="http://www.wowhead.com/?item=12212"><strong>Jungle Stew</strong></a>, <a href="http://www.wowhead.com/?item=12214"><strong>Mystery Stew</strong></a>,<a href="http://www.wowhead.com/?item=12210"><strong> Roast Raptor</strong></a>, <a href="http://www.wowhead.com/?item=3729"><strong>Soothing Turtle Bisque</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 30</strong><br />
    <a href="http://www.wowhead.com/?item=21217"><strong>Sagefish Delight</strong></a><br />
    Increases Mana Regeneration by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 35</strong><br />
    <a href="http://www.wowhead.com/?item=13931"><strong>Nightfin Soup</strong></a><br />
    Increases Mana Regeneration by 6 for 10 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=33004"><strong>Clamlette Magnifique</strong></a><br />
    Increases Attack Power and 14 Spell Power for 1 hour<br />
    <span class="ul style7"><br />
    <strong>Level 45</strong></span><br />
    <a href="http://www.wowhead.com/?item=20452"><strong>Smoked Desert Dumplings</strong></a><br />
    Increases Strength by 20 for 15 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=13928"><strong>Grilled Squid</strong></a><br />
    Increases Agility by 10 for 10 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=35563"><strong>Charred Bear Kabobs</strong></a><br />
    Increases Attack Power by 24 for 15 minutes</p>
  <p><strong class="ul style7">Level 55</strong><br />
    <a href="http://www.wowhead.com/?item=27658"><strong>Roasted Clefthoof</strong></a><br />
    Increases Strength by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27658"><strong>Helboar Bacon</strong></a><br />
    Increases Strength by 20 for 15 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27664"><strong>Grilled Mudfish</strong></a>, <a href="http://www.wowhead.com/?item=27659"><strong>Warp Burger</strong></a><br />
    Increases Agility by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27655"><strong>Ravager Dog</strong></a><br />
    Increases Attack Power by 40 for 30 mins</p>
  <p><span class="style7 ul"><strong>Level 65</strong></span><br />
    <a href="http://www.wowhead.com/?item=33874"><strong>Kiblers Bits</strong></a><br />
    Increases Strength by 20 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=30359"><strong>Oronok’s Tuber of Strength</strong></a><br />
    Increases Strength by 20 for 30 mins</p>
  <p><a href="http://www.wowhead.com/?item=30358"><strong>Oronok’s Tuber of Agility</strong></a><br />
    Increases Agility by 20 for 30 mins</p>
  <p><strong class="ul style7">Level 70</strong><br />
    <a href="http://www.wowhead.com/?item=43000"><strong>Dragonfin Filet</strong></a><br />
    Increases Strength and Stamina by 40 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=42999"><strong>Blackened Dragonfin</strong></a><br />
    Increases Agility and Stamina by 40 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34762"><strong>Grilled Sculpin</strong></a><br />
    Increases Attack Power by 60 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34748"><strong>Mammoth Meal</strong></a><br />
    Increases Attack Power by 60 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34754"><strong>Mega Mammoth Meal</strong></a><br />
    Increases Attack Power by 80 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34766"><strong>Poached Northern Sculpin</strong></a><br />
    Increases Attack Power by 80 for 1 hour<br />
    <br />
    </p>
  <h2><a name="priest" id="priest"></a>Priest</h2>
  <p><strong class="ul style7">Level 1</strong><br />
    <a href="http://www.wowhead.com/?item=12224"><strong>Crispy Bat Wing</strong></a>, <a href="http://www.wowhead.com/?item=17197"><strong>Gingerbread Cookie</strong></a>, <a href="http://www.wowhead.com/?item=6888"><strong>Herb Baked Egg</strong></a>, <a href="http://www.wowhead.com/?item=27635"><strong>Lynx Steak</strong></a>, <a href="http://www.wowhead.com/?item=24105"><strong>Roasted Moongraze Tenderloin</strong></a>, <a href="http://www.wowhead.com/?item=2888"><strong>Beer Basted Boar Ribs</strong></a>, <a href="http://www.wowhead.com/?item=5472"><strong>Kaldorei Spider Kabob</strong></a>, <a href="http://www.wowhead.com/?item=2680"><strong>Spiced Wolf Meat</strong></a>, <a href="http://www.wowhead.com/?item=17198"><strong>Egg Nog</strong></a>, <a href="http://www.wowhead.com/?item=5484"><strong>Roasted Kodo Meat</strong></a><br />
Increases 2 Strength and Stamina for 15 mins<br />
<br />
<strong class="ul style7">Level 5</strong><br />
<a href="http://www.wowhead.com/?item=27636"><strong>Bat Bites</strong></a>, <a href="http://www.wowhead.com/?item=5525"><strong>Boiled Clams</strong></a>, <a href="http://www.wowhead.com/?item=2684"><strong>Coyote Steak</strong></a>, <a href="http://www.wowhead.com/?item=5476"><strong>Fillet of Frenzy</strong></a>, <a href="http://www.wowhead.com/?item=724"><strong>Goretusk Liver Pie</strong></a>, <a href="http://www.wowhead.com/?item=5477"><strong>Strider Stew</strong></a>, <a href="http://www.wowhead.com/?item=3220"><strong>Blood Sausage</strong></a>, <strong><a href="http://www.wowhead.com/?item=22645">Crunchy Spider Surprise</a></strong>, <a href="http://www.wowhead.com/?item=2683"><strong>Crab Cake</strong></a>, <a href="http://www.wowhead.com/?item=3662"><strong>Crocolisk Steak</strong></a>, <a href="http://www.wowhead.com/?item=2687"><strong>Dry Pork Ribs</strong></a><br />
Increases 4 Strength and Stamina for 15 mins<br />
    <br />
    <strong class="ul style7">Level 10</strong><br />
    <a href="http://www.wowhead.com/?item=1082"><strong>Redridge Goulash</strong></a><br />
Increases 6 Strength and Stamina for 15 mins<br />
<br />
<a href="http://www.wowhead.com/?item=21072"><strong>Smoked Sagefish</strong></a><br />
Increases Mana Regeneration by 3 for 15 mins<br />
<br />
<strong class="ul style7">Level 12</strong><br />
<a href="http://www.wowhead.com/?item=5479"><strong>Crispy Lizard Tail</strong></a><br />
Increases 6 Strength and Stamina for 15 mins</p>
  <p><strong class="ul style7">Level 15</strong><br />
    <a href="http://www.wowhead.com/?item=3663"><strong>Murloc Fin Soup</strong></a>, <a href="http://www.wowhead.com/?item=1017"><strong>Seasoned Wolf Kabob</strong></a>, <a href="http://www.wowhead.com/?item=3726"><strong>Big Bear Steak</strong></a>, <a href="http://www.wowhead.com/?item=3666"><strong>Gooey Spider Cake</strong></a>, <a href="http://www.wowhead.com/?item=5480"><strong>Lean Venison</strong></a>, <a href="http://www.wowhead.com/?item=3664"><strong>Crocolisk Gumbo</strong></a>, <a href="http://www.wowhead.com/?item=5527"><strong>Goblin Deviled Clams</strong></a>, <a href="http://www.wowhead.com/?item=3727"><strong>Hot Lion Chops</strong></a>, <a href="http://www.wowhead.com/?item=12209"><strong>Lean Wolf Steak</strong></a>, <a href="http://www.wowhead.com/?item=3665"><strong>Curiously Tasty Omelet</strong></a><br />
Increases Strength and Stamina by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 20</strong><br />
    <a href="http://www.wowhead.com/?item=20074"><strong>Heavy Crocolisk Stew</strong></a>, <a href="http://www.wowhead.com/?item=3728"><strong>Tasty Lion Steak</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 25</strong><br />
    <a href="http://www.wowhead.com/?item=4457"><strong>Barbecued Buzzard Wing</strong></a>, <a href="http://www.wowhead.com/?item=12213"><strong>Carrion Surprise</strong></a>, <a href="http://www.wowhead.com/?item=6038"><strong>Giant Clam Scorcho</strong></a>, <a href="http://www.wowhead.com/?item=13851"><strong>Hot Wolf Ribs</strong></a>, <a href="http://www.wowhead.com/?item=12212"><strong>Jungle Stew</strong></a>, <a href="http://www.wowhead.com/?item=12214"><strong>Mystery Stew</strong></a>,<a href="http://www.wowhead.com/?item=12210"><strong> Roast Raptor</strong></a>, <a href="http://www.wowhead.com/?item=3729"><strong>Soothing Turtle Bisque</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 30</strong><br />
    <a href="http://www.wowhead.com/?item=21217"><strong>Sagefish Delight</strong></a><br />
    Increases Mana Regeneration by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 35</strong><br />
    <a href="http://www.wowhead.com/?item=13931"><strong>Nightfin Soup</strong></a><br />
    Increases Mana Regeneration by 6 for 10 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=12215"><strong>Heavy Kodo Stew</strong></a><br />
    Increases  Spirit by 12 for 15 mins</p>
  <p><a href="http://www.wowhead.com/?item=17222"><strong>Spider Sausage</strong></a><br />
    Increases Spirit by 12 for 15 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=33004"><strong>Clamlette Magnifique</strong></a><br />
    Increases Attack Power and 14 Spell Power for 1 hour<br />
    <br />
    <strong class="ul style7">Level 40</strong><br />
    <a href="http://www.wowhead.com/?item=16971"><strong>Clamlette Surprise</strong></a>, <a href="http://www.wowhead.com/?item=12218"><strong>Monster Omelet</strong></a>, <a href="http://www.wowhead.com/?item=12216"><strong>Spiced Chili Crab</strong></a>, <a href="http://www.wowhead.com/?item=18045">Tender Wolf Steak</a><br />
    Increases Spirit by 12 for 15 mins<br />
    <br />
    <span class="ul style7"><strong>Level 45</strong></span><br />
    <a href="http://www.wowhead.com/?item=18254"><strong>Runn Tum Tuber Surprise</strong></a><br />
    Increases Intellect 10 for 10 mins<br />
    <br />
    <strong class="ul style7">Level 55</strong><br />
    <a href="http://www.wowhead.com/?item=27657"><strong>Blackened Basilisk</strong></a>, <a href="http://www.wowhead.com/?item=31673"><strong>Crunchy Serpent</strong></a>, <a href="http://www.wowhead.com/?item=27666"><strong>Golden Fish Sticks</strong></a>, <a href="http://www.wowhead.com/?item=31672"><strong>Mok'Nathal Shortribs</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27651"><strong>Buzzard Bites</strong></a>, <strong><a href="http://www.wowhead.com/?item=30155">Clam Bar</a></strong>, <a href="http://www.wowhead.com/?item=27662"><strong>Feltail Delight</strong></a>, <a href="http://www.wowhead.com/?item=31672"><strong>Mok'Nathal Shortribs</strong></a>, <a href="http://www.wowhead.com/?item=27660"><strong>Talbuk Steak</strong></a><br />
    Increases Stamina and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27664"><strong>Grilled Mudfish</strong></a>, <a href="http://www.wowhead.com/?item=27655"><strong>Ravager Dog</strong></a>, <a href="http://www.wowhead.com/?item=27658"><strong>Roasted Clefthoof</strong></a>, <a href="http://www.wowhead.com/?item=27659"><strong>Warp Burger</strong></a><br />
    Increases Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27667"><strong>Spicy Crawdad</strong></a><br />
    Increases Stamina by 30 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27663"><strong>Blackened Sporefish</strong></a><br />
    Increases Mana Regeneration by 8 for 30 mins<br />
    <br />
    <strong class="ul style7">Level 65</strong><br />
    <a href="http://www.wowhead.com/?item=33052"><strong>Fisherman's Feast</strong></a><br />
    Increases Stamina by 30 and Spirit by 20 for 30 mins</p>
  <p><a href="http://www.wowhead.com/?item=34411"><strong>Hot Apple Cider</strong></a><br />
    Increases Stamina and Spirit by 20 for 30 mins<br />
    <br />
    Oronok's Tuber of (<a href="http://www.wowhead.com/?item=30358"><strong>Agility</strong></a>, <a href="http://www.wowhead.com/?item=30357"><strong>Healing</strong></a>, <a href="http://www.wowhead.com/?item=30361"><strong>Spell Power</strong></a>, and/or <a href="http://www.wowhead.com/?item=30359"><strong>Strength</strong></a>), <a href="http://www.wowhead.com/?item=33872"><strong>Spicy Hot Talbuk</strong></a><br />
    Increases Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=33825"><strong>Skullfish Soup</strong></a><br />
    Increases Spirit and Spell Critical Hit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27657"><strong>Blackened Basilisk</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <strong class="ul style7">Level 70</strong><br />
    <a href="http://www.wowhead.com/?item=42998"><strong>Cuttlesteak</strong></a><br />
    Increases Spirit and Stamina by 40 for 1 hour<br />
    <br />
  </p>
  <h2><a name="rogue" id="rogue"></a>Rogue</h2>
  <p><strong class="ul style7">Level 1</strong><br />
    <a href="http://www.wowhead.com/?item=12224"><strong>Crispy Bat Wing</strong></a>, <a href="http://www.wowhead.com/?item=17197"><strong>Gingerbread Cookie</strong></a>, <a href="http://www.wowhead.com/?item=6888"><strong>Herb Baked Egg</strong></a>, <a href="http://www.wowhead.com/?item=27635"><strong>Lynx Steak</strong></a>, <a href="http://www.wowhead.com/?item=24105"><strong>Roasted Moongraze Tenderloin</strong></a>, <a href="http://www.wowhead.com/?item=2888"><strong>Beer Basted Boar Ribs</strong></a>, <a href="http://www.wowhead.com/?item=5472"><strong>Kaldorei Spider Kabob</strong></a>, <a href="http://www.wowhead.com/?item=2680"><strong>Spiced Wolf Meat</strong></a>, <a href="http://www.wowhead.com/?item=17198"><strong>Egg Nog</strong></a>, <a href="http://www.wowhead.com/?item=5484"><strong>Roasted Kodo Meat</strong></a><br />
Increases 2 Strength and Stamina for 15 mins<br />
<br />
<strong class="ul style7">Level 5</strong><br />
<a href="http://www.wowhead.com/?item=27636"><strong>Bat Bites</strong></a>, <a href="http://www.wowhead.com/?item=5525"><strong>Boiled Clams</strong></a>, <a href="http://www.wowhead.com/?item=2684"><strong>Coyote Steak</strong></a>, <a href="http://www.wowhead.com/?item=5476"><strong>Fillet of Frenzy</strong></a>, <a href="http://www.wowhead.com/?item=724"><strong>Goretusk Liver Pie</strong></a>, <a href="http://www.wowhead.com/?item=5477"><strong>Strider Stew</strong></a>, <a href="http://www.wowhead.com/?item=3220"><strong>Blood Sausage</strong></a>, <strong><a href="http://www.wowhead.com/?item=22645">Crunchy Spider Surprise</a></strong>, <a href="http://www.wowhead.com/?item=2683"><strong>Crab Cake</strong></a>, <a href="http://www.wowhead.com/?item=3662"><strong>Crocolisk Steak</strong></a>, <a href="http://www.wowhead.com/?item=2687"><strong>Dry Pork Ribs</strong></a><br />
Increases 4 Strength and Stamina for 15 mins<br />
    <br />
    <strong class="ul style7">Level 10</strong><br />
    <a href="http://www.wowhead.com/?item=1082"><strong>Redridge Goulash</strong></a><br />
Increases 6 Strength and Stamina for 15 mins<br />
<br />
<strong class="ul style7">Level 12</strong><br />
<a href="http://www.wowhead.com/?item=5479"><strong>Crispy Lizard Tail</strong></a><br />
Increases 6 Strength and Stamina for 15 mins</p>
  <p><strong class="ul style7">Level 15</strong><br />
    <a href="http://www.wowhead.com/?item=3663"><strong>Murloc Fin Soup</strong></a>, <a href="http://www.wowhead.com/?item=1017"><strong>Seasoned Wolf Kabob</strong></a>, <a href="http://www.wowhead.com/?item=3726"><strong>Big Bear Steak</strong></a>, <a href="http://www.wowhead.com/?item=3666"><strong>Gooey Spider Cake</strong></a>, <a href="http://www.wowhead.com/?item=5480"><strong>Lean Venison</strong></a>, <a href="http://www.wowhead.com/?item=3664"><strong>Crocolisk Gumbo</strong></a>, <a href="http://www.wowhead.com/?item=5527"><strong>Goblin Deviled Clams</strong></a>, <a href="http://www.wowhead.com/?item=3727"><strong>Hot Lion Chops</strong></a>, <a href="http://www.wowhead.com/?item=12209"><strong>Lean Wolf Steak</strong></a>, <a href="http://www.wowhead.com/?item=3665"><strong>Curiously Tasty Omelet</strong></a><br />
Increases Strength and Stamina by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 20</strong><br />
    <a href="http://www.wowhead.com/?item=20074"><strong>Heavy Crocolisk Stew</strong></a>, <a href="http://www.wowhead.com/?item=3728"><strong>Tasty Lion Steak</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 25</strong><br />
    <a href="http://www.wowhead.com/?item=4457"><strong>Barbecued Buzzard Wing</strong></a>, <a href="http://www.wowhead.com/?item=12213"><strong>Carrion Surprise</strong></a>, <a href="http://www.wowhead.com/?item=6038"><strong>Giant Clam Scorcho</strong></a>, <a href="http://www.wowhead.com/?item=13851"><strong>Hot Wolf Ribs</strong></a>, <a href="http://www.wowhead.com/?item=12212"><strong>Jungle Stew</strong></a>, <a href="http://www.wowhead.com/?item=12214"><strong>Mystery Stew</strong></a>,<a href="http://www.wowhead.com/?item=12210"><strong> Roast Raptor</strong></a>, <a href="http://www.wowhead.com/?item=3729"><strong>Soothing Turtle Bisque</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 35</strong><br />
    <a href="http://www.wowhead.com/?item=33004"><strong>Clamlette Magnifique</strong></a><br />
    Increases Attack Power and 14 Spell Power for 1 hour</p>
  <p><strong class="ul style7">Level 45</strong><br />
    <a href="http://www.wowhead.com/?item=13928"><strong>Grilled Squid</strong></a><br />
    Increases Agility by 10 for 10 mins<br />
    <br />
    <a href="Charred Bear Kabobs"><strong>Charred Bear Kabobs</strong></a><br />
    Increases Attack Power by 24 for 15 minutes</p>
  <p><strong class="ul style7">Level 55</strong><br />
    <a href="http://www.wowhead.com/?item=27664"><strong>Grilled Mudfish</strong></a>, <a href="http://www.wowhead.com/?item=27659"><strong>Warp Burger</strong></a><br />
    Increases Agility by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27655"><strong>Ravager Dog</strong></a><br />
    Increases Attack Power by 40 for 30 mins</p>
  <p><strong class="ul style7">Level 65</strong><br />
    <a href="http://www.wowhead.com/?item=30358"><strong>Oronok’s Tuber of Agility</strong></a><br />
    Increases Agility by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=33872"><strong>Spicy Hot Talbuk</strong></a><br />
    Increases Hit Rating by 20 for 30 mins</p>
  <p><strong class="ul style7">Level 70</strong><br />
    <a href="http://www.wowhead.com/?item=42999"><strong>Blackened Dragonfin</strong></a><br />
    Increases Agility and Stamina by 40 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=42996"><strong>Snapper Extreme</strong></a>, <a href="http://www.wowhead.com/?item=44953"><strong>Worg Tartare</strong></a><br />
    Increases Hit Rating and Stamina by 40 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34762"><strong>Grilled Sculpin</strong></a><br />
    Increases Attack Power by 60 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34748"><strong>Mammoth Meal</strong></a><br />
    Increases Attack Power by 60 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34754"><strong>Mega Mammoth Meal</strong></a><br />
    Increases Attack Power by 80 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34766"><strong>Poached Northern Sculpin</strong></a><br />
    Increases Attack Power by 80 for 1 hour<br />
    <br />
  </p>
  <h2><a name="shaman" id="shaman"></a>Shaman</h2>
  <p><strong class="ul style7">Level 1</strong><br />
    <a href="http://www.wowhead.com/?item=12224"><strong>Crispy Bat Wing</strong></a>, <a href="http://www.wowhead.com/?item=17197"><strong>Gingerbread Cookie</strong></a>, <a href="http://www.wowhead.com/?item=6888"><strong>Herb Baked Egg</strong></a>, <a href="http://www.wowhead.com/?item=27635"><strong>Lynx Steak</strong></a>, <a href="http://www.wowhead.com/?item=24105"><strong>Roasted Moongraze Tenderloin</strong></a>, <a href="http://www.wowhead.com/?item=2888"><strong>Beer Basted Boar Ribs</strong></a>, <a href="http://www.wowhead.com/?item=5472"><strong>Kaldorei Spider Kabob</strong></a>, <a href="http://www.wowhead.com/?item=2680"><strong>Spiced Wolf Meat</strong></a>, <a href="http://www.wowhead.com/?item=17198"><strong>Egg Nog</strong></a>, <a href="http://www.wowhead.com/?item=5484"><strong>Roasted Kodo Meat</strong></a><br />
Increases 2 Strength and Stamina for 15 mins<br />
<br />
<strong class="ul style7">Level 5</strong><br />
<a href="http://www.wowhead.com/?item=27636"><strong>Bat Bites</strong></a>, <a href="http://www.wowhead.com/?item=5525"><strong>Boiled Clams</strong></a>, <a href="http://www.wowhead.com/?item=2684"><strong>Coyote Steak</strong></a>, <a href="http://www.wowhead.com/?item=5476"><strong>Fillet of Frenzy</strong></a>, <a href="http://www.wowhead.com/?item=724"><strong>Goretusk Liver Pie</strong></a>, <a href="http://www.wowhead.com/?item=5477"><strong>Strider Stew</strong></a>, <a href="http://www.wowhead.com/?item=3220"><strong>Blood Sausage</strong></a>, <strong><a href="http://www.wowhead.com/?item=22645">Crunchy Spider Surprise</a></strong>, <a href="http://www.wowhead.com/?item=2683"><strong>Crab Cake</strong></a>, <a href="http://www.wowhead.com/?item=3662"><strong>Crocolisk Steak</strong></a>, <a href="http://www.wowhead.com/?item=2687"><strong>Dry Pork Ribs</strong></a><br />
Increases 4 Strength and Stamina for 15 mins<br />
    <br />
    <strong class="ul style7">Level 10</strong><br />
    <a href="http://www.wowhead.com/?item=1082"><strong>Redridge Goulash</strong></a><br />
Increases 6 Strength and Stamina for 15 mins<br />
<br />
<a href="http://www.wowhead.com/?item=21072"><strong>Smoked Sagefish</strong></a><br />
Increases Mana Regeneration by 3 for 15 mins<br />
<br />
<strong class="ul style7">Level 12</strong><br />
<a href="http://www.wowhead.com/?item=5479"><strong>Crispy Lizard Tail</strong></a><br />
Increases 6 Strength and Stamina for 15 mins</p>
  <p><strong class="ul style7">Level 15</strong><br />
    <a href="http://www.wowhead.com/?item=3663"><strong>Murloc Fin Soup</strong></a>, <a href="http://www.wowhead.com/?item=1017"><strong>Seasoned Wolf Kabob</strong></a>, <a href="http://www.wowhead.com/?item=3726"><strong>Big Bear Steak</strong></a>, <a href="http://www.wowhead.com/?item=3666"><strong>Gooey Spider Cake</strong></a>, <a href="http://www.wowhead.com/?item=5480"><strong>Lean Venison</strong></a>, <a href="http://www.wowhead.com/?item=3664"><strong>Crocolisk Gumbo</strong></a>, <a href="http://www.wowhead.com/?item=5527"><strong>Goblin Deviled Clams</strong></a>, <a href="http://www.wowhead.com/?item=3727"><strong>Hot Lion Chops</strong></a>, <a href="http://www.wowhead.com/?item=12209"><strong>Lean Wolf Steak</strong></a>, <a href="http://www.wowhead.com/?item=3665"><strong>Curiously Tasty Omelet</strong></a><br />
Increases Strength and Stamina by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 20</strong><br />
    <a href="http://www.wowhead.com/?item=20074"><strong>Heavy Crocolisk Stew</strong></a>, <a href="http://www.wowhead.com/?item=3728"><strong>Tasty Lion Steak</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 25</strong><br />
    <a href="http://www.wowhead.com/?item=4457"><strong>Barbecued Buzzard Wing</strong></a>, <a href="http://www.wowhead.com/?item=12213"><strong>Carrion Surprise</strong></a>, <a href="http://www.wowhead.com/?item=6038"><strong>Giant Clam Scorcho</strong></a>, <a href="http://www.wowhead.com/?item=13851"><strong>Hot Wolf Ribs</strong></a>, <a href="http://www.wowhead.com/?item=12212"><strong>Jungle Stew</strong></a>, <a href="http://www.wowhead.com/?item=12214"><strong>Mystery Stew</strong></a>,<a href="http://www.wowhead.com/?item=12210"><strong> Roast Raptor</strong></a>, <a href="http://www.wowhead.com/?item=3729"><strong>Soothing Turtle Bisque</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 30</strong><br />
    <a href="http://www.wowhead.com/?item=21217"><strong>Sagefish Delight</strong></a><br />
    Increases Mana Regeneration by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 35</strong><br />
    <a href="http://www.wowhead.com/?item=13931"><strong>Nightfin Soup</strong></a><br />
    Increases Mana Regeneration by 6 for 10 mins</p>
  <p><strong class="ul style7">Level 45</strong><br />
    <a href="http://www.wowhead.com/?item=18254"><strong>Runn Tum Tuber Surprise</strong></a><br />
    Increases Intellect 10 for 10 mins</p>
  <p><a href="http://www.wowhead.com/?item=13928"><strong>Grilled Squid</strong></a><br />
    Increases Agility by 10 for 10 mins</p>
  <p><strong class="ul style7">Level 55</strong><br />
    <a href="http://www.wowhead.com/?item=27664"><strong>Grilled Mudfish</strong></a>, <a href="http://www.wowhead.com/?item=27659"><strong>Warp Burger</strong></a><br />
    Increases Agility by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27663"><strong>Blackened Sporefish</strong></a><br />
    Increases Mana Regeneration by 8 for 30 mins</p>
  <p><strong class="ul style7">Level 65</strong><br />
    <a href="http://www.wowhead.com/?item=30358"><strong>Oronok’s Tuber of Agility</strong></a><br />
    Increases Agility by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=33825"><strong>Skullfish Soup</strong></a><br />
    Increases Critical Strike rating by 20 for 30 mins<br />
  </p>
  <p><strong class="ul style7">Level 70</strong><br />
    <a href="http://www.wowhead.com/?item=42999"><strong>Blackened Dragonfin</strong></a><br />
    Increases Agility and Stamina by 40 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34764"><strong>Poached Nettlefish</strong></a><br />
    Increases Critical Strike rating by 30 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34756"><strong>Spiced Worm Burger</strong></a><br />
    Increases Critical Strike by 40 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34768"><strong>Spicy Blue Nettlefish</strong></a><br />
    Increases Critical Strike by 40 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=39691"><strong>Succulent Orca Stew </strong></a><br />
    Increases Critical Strike by 30 for 1 hour<br />
    <br />
  </p>
  <h2><a name="warlock" id="warlock"></a>Warlock</h2>
  <p><strong class="ul style7">Level 1</strong><br />
    <a href="http://www.wowhead.com/?item=12224"><strong>Crispy Bat Wing</strong></a>, <a href="http://www.wowhead.com/?item=17197"><strong>Gingerbread Cookie</strong></a>, <a href="http://www.wowhead.com/?item=6888"><strong>Herb Baked Egg</strong></a>, <a href="http://www.wowhead.com/?item=27635"><strong>Lynx Steak</strong></a>, <a href="http://www.wowhead.com/?item=24105"><strong>Roasted Moongraze Tenderloin</strong></a>, <a href="http://www.wowhead.com/?item=2888"><strong>Beer Basted Boar Ribs</strong></a>, <a href="http://www.wowhead.com/?item=5472"><strong>Kaldorei Spider Kabob</strong></a>, <a href="http://www.wowhead.com/?item=2680"><strong>Spiced Wolf Meat</strong></a>, <a href="http://www.wowhead.com/?item=17198"><strong>Egg Nog</strong></a>, <a href="http://www.wowhead.com/?item=5484"><strong>Roasted Kodo Meat</strong></a><br />
Increases 2 Strength and Stamina for 15 mins<br />
<br />
<strong class="ul style7">Level 5</strong><br />
<a href="http://www.wowhead.com/?item=27636"><strong>Bat Bites</strong></a>, <a href="http://www.wowhead.com/?item=5525"><strong>Boiled Clams</strong></a>, <a href="http://www.wowhead.com/?item=2684"><strong>Coyote Steak</strong></a>, <a href="http://www.wowhead.com/?item=5476"><strong>Fillet of Frenzy</strong></a>, <a href="http://www.wowhead.com/?item=724"><strong>Goretusk Liver Pie</strong></a>, <a href="http://www.wowhead.com/?item=5477"><strong>Strider Stew</strong></a>, <a href="http://www.wowhead.com/?item=3220"><strong>Blood Sausage</strong></a>, <strong><a href="http://www.wowhead.com/?item=22645">Crunchy Spider Surprise</a></strong>, <a href="http://www.wowhead.com/?item=2683"><strong>Crab Cake</strong></a>, <a href="http://www.wowhead.com/?item=3662"><strong>Crocolisk Steak</strong></a>, <a href="http://www.wowhead.com/?item=2687"><strong>Dry Pork Ribs</strong></a><br />
Increases 4 Strength and Stamina for 15 mins<br />
    <br />
    <strong class="ul style7">Level 10</strong><br />
    <a href="http://www.wowhead.com/?item=1082"><strong>Redridge Goulash</strong></a><br />
Increases 6 Strength and Stamina for 15 mins<br />
<br />
<a href="http://www.wowhead.com/?item=21072"><strong>Smoked Sagefish</strong></a><br />
Increases Mana Regeneration by 3 for 15 mins<br />
<br />
<strong class="ul style7">Level 12</strong><br />
<a href="http://www.wowhead.com/?item=5479"><strong>Crispy Lizard Tail</strong></a><br />
Increases 6 Strength and Stamina for 15 mins</p>
  <p><strong class="ul style7">Level 15</strong><br />
    <a href="http://www.wowhead.com/?item=3663"><strong>Murloc Fin Soup</strong></a>, <a href="http://www.wowhead.com/?item=1017"><strong>Seasoned Wolf Kabob</strong></a>, <a href="http://www.wowhead.com/?item=3726"><strong>Big Bear Steak</strong></a>, <a href="http://www.wowhead.com/?item=3666"><strong>Gooey Spider Cake</strong></a>, <a href="http://www.wowhead.com/?item=5480"><strong>Lean Venison</strong></a>, <a href="http://www.wowhead.com/?item=3664"><strong>Crocolisk Gumbo</strong></a>, <a href="http://www.wowhead.com/?item=5527"><strong>Goblin Deviled Clams</strong></a>, <a href="http://www.wowhead.com/?item=3727"><strong>Hot Lion Chops</strong></a>, <a href="http://www.wowhead.com/?item=12209"><strong>Lean Wolf Steak</strong></a>, <a href="http://www.wowhead.com/?item=3665"><strong>Curiously Tasty Omelet</strong></a><br />
Increases Strength and Stamina by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 20</strong><br />
    <a href="http://www.wowhead.com/?item=20074"><strong>Heavy Crocolisk Stew</strong></a>, <a href="http://www.wowhead.com/?item=3728"><strong>Tasty Lion Steak</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 25</strong><br />
    <a href="http://www.wowhead.com/?item=4457"><strong>Barbecued Buzzard Wing</strong></a>, <a href="http://www.wowhead.com/?item=12213"><strong>Carrion Surprise</strong></a>, <a href="http://www.wowhead.com/?item=6038"><strong>Giant Clam Scorcho</strong></a>, <a href="http://www.wowhead.com/?item=13851"><strong>Hot Wolf Ribs</strong></a>, <a href="http://www.wowhead.com/?item=12212"><strong>Jungle Stew</strong></a>, <a href="http://www.wowhead.com/?item=12214"><strong>Mystery Stew</strong></a>,<a href="http://www.wowhead.com/?item=12210"><strong> Roast Raptor</strong></a>, <a href="http://www.wowhead.com/?item=3729"><strong>Soothing Turtle Bisque</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 30</strong><br />
    <a href="http://www.wowhead.com/?item=21217">Sagefish Delight</a><br />
    Increases Mana Regeneration by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 35</strong><br />
    <a href="http://www.wowhead.com/?item=13931"><strong>Nightfin Soup</strong></a><br />
    Increases Mana Regeneration by 6 for 10 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=33004"><strong>Clamlette Magnifique</strong></a><br />
    Increases Attack Power and 14 Spell Power for 1 hour<br />
    <br />
    <span class="ul style7"><strong>Level 45</strong></span><br />
    <a href="http://www.wowhead.com/?item=18254"><strong>Runn Tum Tuber Surprise</strong></a><br />
    Increases Intellect 10 for 10 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=35565"><strong>Juicy Bear Burger</strong></a><br />
    Increases Spell Power by 14 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 55</strong><br />
    <a href="http://www.wowhead.com/?item=27657"><strong>Blackened Basilisk</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <a href="http://www.wowhead.com/?item=31673"><strong><br />
    Crunchy Serpent</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27666"><strong>Golden Fish Sticks</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27665"><strong>Poached Bluefish</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins</p>
  <p><a href="http://www.wowhead.com/?item=27663"><strong>Blackened Sporefish</strong></a><br />
    Increases Mana Regeneration by 8 for 30 mins<br />
    <br />
    <strong class="ul style7">Level 65</strong><br />
    <a href="http://www.wowhead.com/?item=27657"><strong>Blackened Basilisk</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <strong class="ul style7">Level 70</strong><br />
    <a href="http://www.wowhead.com/?item=30357"><strong>Oronok's Tuber of Healing</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="Oronok's Tuber of Spell Power"><strong>Oronok's Tuber of Spell Power</strong></a><br />
    Increases Spell Power by 23 and Spirit by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=34767"><strong>Firecracker Salmon</strong></a><br />
    Increases Spell Power by 46 and 40 Stamina for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34749"><strong>Shoveltusk Steak</strong></a><br />
    Increases Spell Power by 46 and 40 Stamina for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34763"><strong>Smoked Salmon</strong></a><br />
    Increases Spell Power by 35 and 40 Stamina for 1 hour<br />
    <br />
    <a href="Tender Shoveltusk Steak"><strong>Tender Shoveltusk Steak</strong></a><br />
    Increases Spell Power by 46 and 40 Stamina for 1 hour<br />
    <br />
  </p>
  <h2><a name="warrior" id="warrior"></a>Warrior</h2>
  <p><strong class="ul style7">Level 1</strong><br />
    <a href="http://www.wowhead.com/?item=12224"><strong>Crispy Bat Wing</strong></a>, <a href="http://www.wowhead.com/?item=17197"><strong>Gingerbread Cookie</strong></a>, <a href="http://www.wowhead.com/?item=6888"><strong>Herb Baked Egg</strong></a>, <a href="http://www.wowhead.com/?item=27635"><strong>Lynx Steak</strong></a>, <a href="http://www.wowhead.com/?item=24105"><strong>Roasted Moongraze Tenderloin</strong></a>, <a href="http://www.wowhead.com/?item=2888"><strong>Beer Basted Boar Ribs</strong></a>, <a href="http://www.wowhead.com/?item=5472"><strong>Kaldorei Spider Kabob</strong></a>, <a href="http://www.wowhead.com/?item=2680"><strong>Spiced Wolf Meat</strong></a>, <a href="http://www.wowhead.com/?item=17198"><strong>Egg Nog</strong></a>, <a href="http://www.wowhead.com/?item=5484"><strong>Roasted Kodo Meat</strong></a><br />
Increases 2 Strength and Stamina for 15 mins</p>
  <p><strong class="ul style7">Level 4</strong><br />
    <a href="http://www.wowhead.com/?item=5631"><strong>Rage Potion</strong></a><br />
    Increases Rage by 20 to 40<br />
      <br />
      <strong class="ul style7">Level 5</strong><br />
      <a href="http://www.wowhead.com/?item=27636"><strong>Bat Bites</strong></a>, <a href="http://www.wowhead.com/?item=5525"><strong>Boiled Clams</strong></a>, <a href="http://www.wowhead.com/?item=2684"><strong>Coyote Steak</strong></a>, <a href="http://www.wowhead.com/?item=5476"><strong>Fillet of Frenzy</strong></a>, <a href="http://www.wowhead.com/?item=724"><strong>Goretusk Liver Pie</strong></a>, <a href="http://www.wowhead.com/?item=5477"><strong>Strider Stew</strong></a>, <a href="http://www.wowhead.com/?item=3220"><strong>Blood Sausage</strong></a>, <strong><a href="http://www.wowhead.com/?item=22645">Crunchy Spider Surprise</a></strong>, <a href="http://www.wowhead.com/?item=2683"><strong>Crab Cake</strong></a>, <a href="http://www.wowhead.com/?item=3662"><strong>Crocolisk Steak</strong></a>, <a href="http://www.wowhead.com/?item=2687"><strong>Dry Pork Ribs</strong></a><br />
    Increases 4 Strength and Stamina for 15 mins<br />
    <br />
    <strong class="ul style7">Level 10</strong><br />
    <a href="http://www.wowhead.com/?item=1082"><strong>Redridge Goulash</strong></a><br />
    Increases 6 Strength and Stamina for 15 mins<br />
      <br />
      <strong class="ul style7">Level 12</strong><br />
      <a href="http://www.wowhead.com/?item=5479"><strong>Crispy Lizard Tail</strong></a><br />
    Increases 6 Strength and Stamina for 15 mins</p>
  <p><strong class="ul style7">Level 15</strong><br />
    <a href="http://www.wowhead.com/?item=3663"><strong>Murloc Fin Soup</strong></a>, <a href="http://www.wowhead.com/?item=1017"><strong>Seasoned Wolf Kabob</strong></a>, <a href="http://www.wowhead.com/?item=3726"><strong>Big Bear Steak</strong></a>, <a href="http://www.wowhead.com/?item=3666"><strong>Gooey Spider Cake</strong></a>, <a href="http://www.wowhead.com/?item=5480"><strong>Lean Venison</strong></a>, <a href="http://www.wowhead.com/?item=3664"><strong>Crocolisk Gumbo</strong></a>, <a href="http://www.wowhead.com/?item=5527"><strong>Goblin Deviled Clams</strong></a>, <a href="http://www.wowhead.com/?item=3727"><strong>Hot Lion Chops</strong></a>, <a href="http://www.wowhead.com/?item=12209"><strong>Lean Wolf Steak</strong></a>, <a href="http://www.wowhead.com/?item=3665"><strong>Curiously Tasty Omelet</strong></a><br />
Increases Strength and Stamina by 6 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 20</strong><br />
    <a href="http://www.wowhead.com/?item=20074"><strong>Heavy Crocolisk Stew</strong></a>, <a href="http://www.wowhead.com/?item=3728"><strong>Tasty Lion Steak</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins<br />
    <br />
    <strong class="ul style7">Level 25</strong><br />
    <a href="http://www.wowhead.com/?item=4457"><strong>Barbecued Buzzard Wing</strong></a>, <a href="http://www.wowhead.com/?item=12213"><strong>Carrion Surprise</strong></a>, <a href="http://www.wowhead.com/?item=6038"><strong>Giant Clam Scorcho</strong></a>, <a href="http://www.wowhead.com/?item=13851"><strong>Hot Wolf Ribs</strong></a>, <a href="http://www.wowhead.com/?item=12212"><strong>Jungle Stew</strong></a>, <a href="http://www.wowhead.com/?item=12214"><strong>Mystery Stew</strong></a>,<a href="http://www.wowhead.com/?item=12210"><strong> Roast Raptor</strong></a>, <a href="http://www.wowhead.com/?item=3729"><strong>Soothing Turtle Bisque</strong></a><br />
Increases Strength and Stamina by 8 for 15 mins</p>
  <p><a href="http://www.wowhead.com/?item=4457"><strong>Great Rage Potion</strong></a><a href="http://www.wowhead.com/?item=3729"><strong></strong></a><br />
Increases Rage by 30 to 60<br />
    <br />
    <strong class="ul style7">Level 35</strong><br />
    <a href="http://www.wowhead.com/?item=13931"><strong>Nightfin Soup</strong></a><br />
    Increases Mana Regeneration by 6 for 10 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=33004"><strong>Clamlette Magnifique</strong></a><br />
    Increases Attack Power and 14 Spell Power for 1 hour<br />
    <br />
    <strong class="ul style7">Level 45</strong><br />
    <a href="http://www.wowhead.com/?item=20452"><strong>Smoked Desert Dumplings</strong></a><br />
    Increases Strength by 20 for 15 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=13928"><strong>Grilled Squid</strong></a><br />
    Increases Agility by 10 for 10 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=35563"><strong>Charred Bear Kabobs</strong></a><br />
    Increases Attack Power by 24 for 15 minutes</p>
  <p><strong class="ul style7">Level 46</strong><br />
    <a href="http://www.wowhead.com/?item=13442"><strong>Mighty Rage Potion</strong></a><br />
Increases Rage by 45 to 75 and increases Strength by 60 for 20 seconds</p>
  <p><strong class="ul style7">Level 50</strong><br />
    <a href="http://www.wowhead.com/?item=22828"><strong>Insane Strength Potion</strong></a><br />
Increases Strength by 120 and decreses your defense rating by 75 for 15 seconds</p>
  <p><strong class="ul style7">Level 55</strong><br />
    <strong><a href="http://www.wowhead.com/?item=27658">Roasted Clefthoof</a></strong><br />
    Increases Strength by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=29292"><strong>Helboar Bacon</strong></a><br />
    Increases Strength by 20 for 15 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27664"><strong>Grilled Mudfish</strong></a>, <a href="http://www.wowhead.com/?item=27659"><strong>Warp Burger</strong></a><br />
    Increases Agility by 20 for 30 mins<br />
    <br />
    <a href="http://www.wowhead.com/?item=27655"><strong>Ravager Dog</strong></a><br />
    Increases Attack Power by 40 for 30 mins</p>
  <p><strong class="ul style7">Level 60</strong><br />
    <strong><a href="http://www.wowhead.com/?item=22837">Heoric Potion</a></strong><br />
Increases Strength by 70 for 15 seconds</p>
  <p><strong class="ul style7">Level 65</strong><br />
    <a href="http://www.wowhead.com/?item=30359"><strong>Oronok’s Tuber of Strength</strong></a><br />
    Increases Strength by 20 for 30 mins</p>
  <p><a href="http://www.wowhead.com/?item=30359"><strong>Oronok’s Tuber of Agility</strong></a><br />
    Increases Agility by 20 for 30 mins</p>
  <p><strong class="ul style7">Level 70</strong><br />
    <a href="http://www.wowhead.com/?item=43000"><strong>Dragonfin Filet</strong></a><br />
    Increases Strength and Stamina by 40 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=42999"><strong>Blackened Dragonfin</strong></a><br />
    Increases Agility and Stamina by 40 for 1 hour<br />
    <br />
    <a href="http://www.wowhead.com/?item=34762"><strong>Grilled Sculpin</strong></a><br />
    Increases Attack Power by 60 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34748"><strong>Mammoth Meal</strong></a><br />
    Increases Attack Power by 60 for 1 hour</p>
  <p><a href="http://www.wowhead.com/?item=34754"><strong>Mega Mammoth Meal</strong></a><br />
    Increases Attack Power by 80 for 1 hour</p>
  <p><strong><a href="http://www.wowhead.com/?item=34766">Poached Northern Sculpin</a></strong><br />
    Increases Attack Power by 80 for 1 hour</p>
  </div>
</div>
<div id="footer">
  <p>Copyright © 2009 Zygor Guides, LLC. All Rights Reserved.</p>
</div>
</div>
</body>
</html>