<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<!--
##  Zygor Guides | version 1.0 | "PEACH"
##  [ www.zygorguides.com ] [ www.tikitula.com ]
##
##  All contents within are Copyright © 2008, Zygor Guides LLC & The Tiki Tula.
##  All Rights Reserved ® 
-->
<head>
<title>Zygor Guides</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="The #1 best-selling in-game World of Warcraft leveling guides." />
<meta name="keywords" content="world of warcraft guide, world of warcraft leveling, wow leveling guide, alliance leveling guide, horde leveling guide, 1-80 leveling guide, in game leveling guides" />
<meta name="language" content="en-us, english" />
<meta name="classification" content="Blog" />
<meta name="author" content="Andrew Sturgeon" />
<meta name="copyright" content="Zygor Guides LLC" />
<link rel="shortcut icon" href="/favicon.ico" />
<link rel="alternate" type="application/rss+xml" title="The Zygor Guides News Feed" href="http://feeds.feedburner.com/zygorguides" />
<style type='text/css' media='screen'>
<!--
@import url(../css/peach.css);
-->
</style>
<script type="text/javascript" src="../js/flashembed.js"></script>
<script type="text/javascript" src="../js/dropdown.js"></script>
</head>
<body>
<div id="container">
<div id="header"></div>
<div id="navigation">
<ul>
<li><a href="../news/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu1, '150px')" onmouseout="delayhidemenu()">Home</a></li>
<li><a href="../about/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu2, '150px')" onmouseout="delayhidemenu()">About</a></li>
<li><a href="../guides/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu3, '150px')" onmouseout="delayhidemenu()">Guides</a></li>
<li><a href="../freetrial/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu4, '150px')" onmouseout="delayhidemenu()">Free Trial</a></li>
<li><a href="index.php" onclick="" onmouseover="dropdownmenu(this, event, menu5, '150px')" onmouseout="delayhidemenu()">Members Area</a></li>
<li><a href="../forum/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu6, '150px')" onmouseout="delayhidemenu()">Forum</a></li>
<li><a href="../faq/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu7, '150px')" onmouseout="delayhidemenu()">FAQ</a></li>
<li><a href="../contact/index.php" onclick="" onmouseover="dropdownmenu(this, event, menu8, '150px')" onmouseout="delayhidemenu()">Contact</a></li>
</ul>
</div>
<div id="content">
<div id="main">
<h2>Log In</h2>
<div id="login">
<form action="http://www.zygorguides.com/amember/login.php" method=post>
<label for="username">Username:</label> <input type=text name=amember_login size=20><br>
<label for="password">Password:</label> <input type=password name=amember_pass size=20><br>
<input type=submit value=Login>
</form>
</div>

</div>
</div>
<div id="sidebar">
<div class="feedbox">
<h2>Subscribe:</h2>
<form method="post" action="http://www.aweber.com/scripts/addlead.pl" target="_new">
<input type="hidden" name="meta_web_form_id" value="1486465894">
<input type="hidden" name="meta_split_id" value="">
<input type="hidden" name="unit" value="zygorguides">
<input type="hidden" name="redirect" value="http://www.aweber.com/form/thankyou_vo.html" id="redirect_56c3aaf87f8c201c3fd33ea0bde91a78">
<input type="hidden" name="meta_redirect_onlist" value="">
<input type="hidden" name="meta_adtracking" value="">
<input type="hidden" name="meta_message" value="1">
<input type="hidden" name="meta_required" value="from">
<input type="hidden" name="meta_forward_vars" value="0">
<label for="username"><em>We respect your privacy</em></label>
<input type="text" name="field-name-here" onclick="this.value='';" onfocus="this.select()" onblur="this.value=!this.value?'Enter Email Address':this.value;" value="Enter Email Address" />
<div class="buttonarea">
<input type="submit" name="submit" value="Sign Up!">
</div>
</form>
<div class="center">
<p>Sign up to our newsletter for free guides, tips and important news regarding our products</p>
</div>
</div>
<div class="sidebox">
<h2>Recent Forum Posts:</h2>
<div id="topics">
<div class="darkbox">
<p><span class="topicheader"><a href="">Fastest class to level?</a></span></p>
<p><span class="topicdetails">Posted on June 23, 2008 at 11:23am</span></p>
</div>
<div class="lightbox">
<p><span class="topicheader"><a href="">Honor should still be wipe</a></span></p>
<p><span class="topicdetails">Posted on June 23, 2008 at 11:23am</span></p>
</div>
<div class="darkbox">
<p><span class="topicheader"><a href="">Brewfest need quick response</a></span></p>
<p><span class="topicdetails">Posted on June 23, 2008 at 11:23am</span></p>
</div>
<div class="lightbox">
<p><span class="topicheader"><a href="">Mount question & road idea</a></span></p>
<p><span class="topicdetails">Posted on June 23, 2008 at 11:23am</span></p>
</div>
</div>
<img src="file:///C|/Documents and Settings/Owner/My Documents/Websites/img/gnomeposts.png" /></img>
</div>
<div class="sidebox">
<h2>Testimonials:</h2>
<blockquote>
<p>I want to thank you for such a great  alliance leveling guide. I was new to WOW in December and started leveling a character using your alliance leveling guide starting in Feb. I have ran few instances and done most of the quests solo with a bit of help from my son’s Level 70 here and there. I took my time and tried to learn the game. As of this AM, your alliance leveling guide has brought me to level 60.  It has grown to be something I can trust will not waste my time if I stay on course.<br /> - Glyn </p>
</blockquote>
<p class="textright"><a href="">Read More »</a></p>
</div>
</div>
<div id="footer">
  <p>Copyright © 2009 Zygor Guides, LLC. All Rights Reserved. Designed by <a href="">The Tiki Tula</a>.</p>
</div>
</div>
</body>